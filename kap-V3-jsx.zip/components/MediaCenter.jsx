import React, { useState } from 'react';
import Masonry, {ResponsiveMasonry} from "react-responsive-masonry"
import styles from '../styles/MediaCenter.module.scss';
import Image from 'next/image';
import Link from 'next/link';

function MediaCenter({
  presscoverage,
  pressrelease
}) {

  const [presscoverages, setPressCoverages] = useState(presscoverage);
  const [pressreleases, setPressReleases] = useState(pressrelease);

  const coverageHandler = (event) => {
    event.preventDefault();
    setPressReleases([]);
    setPressCoverages(presscoverage);
  };

  const releaseHandler = (event) => {
    event.preventDefault();
    setPressCoverages([]);
    setPressReleases(pressrelease)
  };

  const allHandler = (event) => {
    event.preventDefault();
    setPressCoverages(presscoverage);
    setPressReleases(pressrelease)
  };

  return (
    <section
      // eslint-disable-next-line react/jsx-props-no-spreading
      className={styles.hero}>

    <div className={styles.masonryMain}>
      <div className={styles.all}>
        <span>All</span>
      </div>
      <div className={styles.terms}>
        <Link href="/">
        <a>
          <span className={styles.sortButton}><span onClick={allHandler}>All</span></span>
        </a>
        </Link>
        <span className={styles.textSep}>/</span>
        <Link href="/">
        <a>
          <span className={styles.sortButton}><span onClick={allHandler}>Events</span></span>
        </a>
        </Link>
        <span className={styles.textSep}>/</span>
        <Link href="/">
          <a><span className={styles.sortButton}><span onClick={coverageHandler}>Press Coverages</span></span>
          </a>
        </Link>
          <span className={styles.textSep}>/</span>
        <Link href="/">
          <a><span className={styles.sortButton}><span onClick={releaseHandler}>Press Releases</span></span>
          </a>
        </Link>
      </div>
    </div>
    <div className={styles.wrap}>
     <ResponsiveMasonry columnsCountBreakPoints={{350: 2, 750: 3, 900: 5}}>
      <Masonry>
        {presscoverages?.data?.pressCoverages?.edges.map((item, i) => 
          ((item?.node?.featuredImage?.node?.uri && item?.node?.featuredImage?.node?.sourceUrl) && <div key={`${i}i`} className={styles.containerImage}><Link href={item?.node?.featuredImage?.node?.uri} passHref><a target="_blank">
            <Image
              className={styles.imgPad}
              key={i}
              src={item?.node?.featuredImage?.node?.sourceUrl}
              width={500}
              height={500}
              alt={item?.node?.title}
            /></a></Link></div>)
        )}
        {pressreleases?.data?.pressReleases?.edges.map((item, j) => (
          <div key={`${j}j`} className={styles.containerImage}>
            {item?.node?.uri && <Link href={item?.node?.uri}><a target="_blank">
            <Image
              className={styles.imgPad}
              src={`/images/image.jpg`}
              width={500}
              height={500}
              alt={item?.node?.title}
          />
          <h5 className={styles.titleRelease}>{item?.node?.title}</h5></a></Link>}
        </div>
        )
        )}
      </Masonry>
    </ResponsiveMasonry>
  </div> 
    </section>
  );
}

export default MediaCenter;
