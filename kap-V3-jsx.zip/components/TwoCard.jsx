import React from 'react';
import styles from '../styles/TwoCard.module.scss';
import Link from 'next/link';
import Image from 'next/image';
 
function TwoCard({
    cardData
}) {

  return (
    <div className={styles.wrap}>
      <div className={styles.CardNav}>
      {cardData.map((item, index)=>(
        <div key={`${index}12`} className={styles.column}>
        <div className={styles.card}>
            {item?.image && (
              <Link href={`/`} passHref>
                <a><Image
                  alt="Cards"
                  src={item?.image}
                  layout="intrinsic"
                  width={100}
                  height={100}
                /></a>
              </Link>
            )}
          <div>{item?.title}</div>
          <div className={styles.cardDesc}>{item?.data}</div>
        </div>
        </div>
      ))}
      </div>
    </div>
  )
}

export default TwoCard;