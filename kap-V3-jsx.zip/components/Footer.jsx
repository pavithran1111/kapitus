import React from 'react';
import styles from '../styles/Footer.module.scss';
import Signupnewsletter from "./SignUpNewsLetter"
import { useRouter } from "next/router";
import UtmParams from "./UtmParams"
import Link from 'next/link';

function Footer({
  title = ' ',
  description,
}) {

  let { asPath } = useRouter();
  let params = UtmParams(asPath)
  const ColumnOne = [{label:"Media Center", url: `/media-center/${params}`}, {label:"Team", url:`/about-us/${params}`}, {label:"Careers", url:"https://kapitus.breezy.hr/"}, {label: "Events", url: `/events${params}`}, {label: "Success Stories", url: `/success-stories/${params}`}, {label: "The Kapitus Difference", url: `/the-kapitus-difference/${params}`}, {label: "Developer Documentation", url: `/developer-documentation/${params}`}, {label: "Blog", url: `/blog/${params}`}]

  const ColumnTwo = [{label:"Revenue Based Financing", url: `/products-services/revenue-based-financing/${params}`}, {label:"Helix Healthcare Financing", url:`/products-services/helix-healthcare-financing/${params}`}, {label: "Business Loans", url: `/products-services/business-loans/${params}`}, {label: "SBA Loans", url: `/products-services/sba-loans/${params}`}, {label: "Line of Credit", url: `/products-services/line-of-credit/${params}`}, {label: "Invoice Factoring", url: `/products-services/invoice-factoring/${params}`}, {label: "Equipment Financing", url: `/products-services/equipment-financing/${params}`}, {label: "Purchase Order Financing", url: `/products-services/purchase-order-financing/${params}`}, {label: "Concierge Services", url: `/products-services/concierge-services/${params}`}]

  const ColumnThree = [{label:'(800) 780-7133', url:"tel:18007807133"}, {label:'Contact Us', url: `/contact-us/${params}`}]
  
// function Footer({ copyrightHolder = 'Company Name' }: Props): JSX.Element {
//  const year = new Date().getFullYear();
  return (
 //   <footer className={styles.main}>
//      <div className={styles.wrap}>
//        <p>{`© ${year} ${copyrightHolder}. All rights reserved.`}</p>
//      </div>
//    </footer>
<footer className={styles.footer}>
<div className={styles.wrap}>
  <div className={styles['title-wrap']}>
    <p className={styles['site-title']}>
      <Link href="/">
        <a>{title}</a>
      </Link>
    </p>
 
    {description && <p className={styles.description}>{description}</p>}
  </div>

  <div className={styles.features}>
    <ul>
      <h2 className="title-font font-medium text-kapitus tracking-widest text-sm mb-3">
        <Link href="/about-us" passHref>About Us</Link>
      </h2>
      {ColumnOne?.map((link, _index) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={link.url}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    <ul>
      <h2 className="title-font font-medium text-kapitus tracking-widest text-sm mb-3">
        <Link href="/products-we-offer" passHref>Products</Link>
      </h2>
      {ColumnTwo?.map((link) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={`${link.url}`}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    <ul>
    <h2 className="title-font font-medium text-kapitus tracking-widest text-sm mb-3">
        <Link href="/contact-us" passHref>Contact Us</Link>
      </h2>
      {ColumnThree?.map((link) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={`${link.uri}`}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    {/* <ul>
      <li> 
          <h5> Signup For Our Newsletter</h5>
          <input type="text" name="Email" />
      </li>
    </ul> */}
    <div className="xs:text-left md:text-center">
           
 {/*     <h5 className="md: p-5"> Signup For Our Newsletter</h5>
       <input type="text" name="Email" className="p-2" /> 
      <div className="my-5 button"><button>Join Now</button></div> */}
      <Signupnewsletter credentials={`credentials`} />
    </div>
    {/* 
      <li>
        <Link href="https://github.com/wpengine/faustjs">
          <a
            className="button"
            href="https://github.com/wpengine/faustjs">
            GitHub
          </a>
        </Link>
  
      </li>
    */}
  </div>
</div>
</footer>
  );
}

export default Footer;