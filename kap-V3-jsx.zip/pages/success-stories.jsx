import { getApolloClient } from '../lib/apollo-client';
import { gql } from '@apollo/client'
import Header from "../components/Header"
import Footer from "../components/Footer"
import Hero from "../components/Hero"
import CommonCard from "../components/CommonCard"
import Carousel from "../components/Carousel"
import Head from 'next/head';
import LastCTA from '../components/LastCTA';

export default function PageComponent({ SuccessStories }) {

  const baseVar = SuccessStories?.data?.data;
  const cardGroup = [baseVar?.page?.CardRows?.cardGroup1, baseVar?.page?.CardRows?.cardGroup2, baseVar?.page?.CardRows?.cardGroup3 ]
  const carousel = [baseVar?.page?.carousel?.carouselGroup1, baseVar?.page?.carousel?.carouselGroup2, baseVar?.page?.carousel?.carouselGroup3]
  return (
    <> 
      <Header
      title={baseVar?.generalSettings?.title}
      description={baseVar?.generalSettings?.description}
    />
    <Head>
      <title>
        {baseVar?.generalSettings?.title} - {baseVar?.generalSettings?.description}
      </title>
    </Head>
    <main className="content"> 
    <Hero
      title={baseVar?.page?.hero?.bannerHeading}
      bgImage={baseVar?.page?.hero?.desktopBanner?.sourceUrl}
      slug={baseVar?.page?.slug}
    />

    <CommonCard
        cardMainTitle={baseVar?.page?.CardRows?.cardMainTitle}
        cardData={cardGroup}
        cardData1={[]}
        cardData2={[]}
    />
    <Carousel data={carousel} />
    <LastCTA
      title={baseVar?.page?.finalCta?.finalSectionTitle} 
      subtitle={''}
      description={baseVar?.page?.finalCta.finalSectionDescription}
      buttonText={baseVar?.page?.finalCta?.finalSectionButton?.title}
      buttonURL={baseVar?.page?.finalCta?.finalSectionButton?.url}
    />
{/*       <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: baseVar?.page?.content() ?? '' }} />
        </div>
        </main>*/} 
      </main>
      <Footer copyrightHolder={baseVar?.generalSettings?.title} />
    </>
  );
}

export async function getStaticProps(context) {
  const apolloClient = getApolloClient();

  const data = await apolloClient.query({
    query: gql`
    query SuccessStories {
      page(id: "success-stories", idType: URI) {
        title
        slug
        hero {
          desktopBanner {
            sourceUrl
            slug
          }
          bannerHeading
        }
        carousel {
          carouselGroup1 {
            companyTitle
            carouselImageDesktop {
              sourceUrl
            }
            testimonial
            companyOwnerName
          }
          carouselGroup2 {
            companyTitle
            carouselImageDesktop {
              sourceUrl
            }
            testimonial
            companyOwnerName
          }
          carouselGroup3 {
            companyTitle
            carouselImageDesktop {
              sourceUrl
            }
            testimonial
            companyOwnerName
          }
        }
        CardRows {
          cardMainTitle
          cardGroup1 {
            cardDescription
            cardTitle
            cardIcon {
              sourceUrl
            }
          }
          cardGroup2 {
            cardDescription
            cardTitle
            cardIcon {
              sourceUrl
            }
          }
          cardGroup3 {
            cardDescription
            cardTitle
            cardIcon {
              sourceUrl
            }
          }
        }
        finalCta {
          finalSectionTitle
          finalSectionDescription
          finalSectionButton {
            title
            url
          }
        }
      }
      generalSettings {
        title
        description
      }
    }`
  });

  return {
    props: {
      SuccessStories: { data },
    },
    revalidate: 1,
  };
}