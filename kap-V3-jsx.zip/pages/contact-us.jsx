import { useEffect, useState } from "react";
import { getApolloClient } from '../lib/apollo-client';
import { gql } from '@apollo/client'
import axios from 'axios';
import Head from 'next/head';
import Image from 'next/image'
import Header from "../components/Header"
import Footer from "../components/Footer"
import { useRouter } from "next/router";
import ContactForm from "../components/forms/ContactForm"

const formId = {1: 'first', 8: 'last', 2: 'email', 14: 'state', 4: 'company', 9: 'connect', 6: 'message'}

const Contactus = ({ ContactUs }) =>  {
  const baseVar = ContactUs?.data?.data;
  const router = useRouter();
  //const [data, setData] = useState(null);
  const [show, setShow] = useState(true);
  const [refill, setRefill] = useState(null);
  //const [error2, setError2] = useState(null);

/*   useEffect(() => {
    //  let refData = {}
      let refillData = {}
      if(Object.entries(props.gfentrydata).length > 0){
          //console.log(props.gfentrydata)
          Object.keys(props.gfentrydata).forEach(function(item, key) {
              if(props.gfentrydata[item] !== '' && !isNaN(item)) {
                  if(item == 6){
                      let dateevent = props.gfentrydata[item].split('/')
                      dateevent.forEach(function(item1, index) {
                          refillData[formId[6+"."+(index+1)]] = item1
                      })
                  }
                  else {
                      refillData[formId[item]] = props.gfentrydata[item];
                  }
                  // refData[item] = props.gfentrydata[item];
              }
          });
      }
      //refData['form_id'] = '33'
      //setData(refData);
      setRefill(refillData)
  }, [props.gfentrydata]) */


return (
      <> 
      <Header
      title={baseVar?.generalSettings?.title}
      description={baseVar?.generalSettings?.description}
    />
    <Head>
      <title>
        {baseVar?.generalSettings?.title} - {baseVar?.generalSettings?.description}
      </title>
    </Head>
    <main className="content">
    <div className="bg-gray-100">
    <div className="mx-auto rounded-lg overflow-hidden">
      <div className="md:flex" style={{backgroundColor:'#e6ebef'}}>
      <div className="relative w-full overflow-hidden">
        <Image alt="contact-us" width="700" height="570" src="/images/contact-us.jpg" className="w-full h-full" />
        <div className="absolute w-full py-24 bottom-0 inset-x-0  text-kapitus text-xl font-bold text-center leading-4">Contact Us</div>
      </div>
      <div className="w-full p-5 px-10 bg-kapitus" id="form1">
        <ContactForm />                
      </div>
      </div>
    </div>
    </div>
    </main>
    <Footer copyrightHolder={`title`} />
    </>
    )
}

export default Contactus;

export async function getStaticProps(context) {

  const apolloClient = getApolloClient();

  const data = await apolloClient.query({
    query: gql`
      query ContactUs {
        page(id: "contact-us", idType: URI) {
          title
          slug
        }
        generalSettings {
          title
          description
        }
      }`
  });
  return {
    props: {
      ContactUs: { data },
    },
    revalidate: 1, // 60 seconds
  };
}