import { getApolloClient } from '../lib/apollo-client';
import { gql } from '@apollo/client'
import Header from "../components/Header"
import Footer from "../components/Footer"
import Hero from "../components/Hero"
import TwoCard from "../components/TwoCard"
import MediaCenter from "../components/MediaCenter"
import styles from "../styles/MediaCenter.module.scss";
import Head from 'next/head';

export default function PageComponent({ page, presscoverage, pressrelease }) {

const baseVar = page?.data;
const cardGroup = [{image:"/images/Call-Us.svg",title:"CALL US", data:"(646) 722-1484"},{image:"/images/Email-Us.svg",title:"EMAIL US", data:"pr@kapitus.com"}]

return (
  <>
    <Header
      title={baseVar?.generalSettings?.title}
      description={baseVar?.generalSettings?.description}
    />
    <Head>
      <title>
        {baseVar?.generalSettings?.title} - {baseVar?.generalSettings?.description}
      </title>
    </Head>
    <main className="content">     
      <Hero
        title={baseVar?.page?.hero?.bannerHeading}
        bgImage={baseVar?.page?.hero?.desktopBanner?.sourceUrl}
        slug={baseVar?.page?.slug}
      />
      <TwoCard cardData={cardGroup} />
      <MediaCenter presscoverage={presscoverage} pressrelease={pressrelease} />
      <div className={styles.masonry}><div className={styles.container}><div className={styles.content}><div className="post-entry post-entry-type-pag"><div className={styles.contentWrapper}><br />
      <div><form action="https://ada-kapitus.com/" id="searchform_element" className={styles.searchElement} method="get"><div className={styles.searchform}><input type="text" id="s" name="s" placeholder="Keyword or Title" className={styles.text} /><div className={styles.searchSubmit}><input type="submit" value="SEARCH MEDIA" id="searchsubmit" className={styles.buttonSearch} /></div><input type="hidden" name="numberposts" value={40} /><input type="hidden" name="post_type[]" value="press_releases" /><input type="hidden" name="post_type[]" value="kap_events" /><input type="hidden" name="post_type[]" value="press_coverage" /><input type="hidden" name="results_hide_fields" /></div></form></div></div></div></div></div></div>
    </main>
    <Footer copyrightHolder={baseVar?.generalSettings?.title} />
  </>
);
}

export async function getStaticProps(context) {
const apolloClient = getApolloClient();

const page = await apolloClient.query({
  query: gql`
  query MediaCenter {
    page(id: "media-center", idType: URI) {
      hero {
        bannerHeading
        desktopBanner {
          sourceUrl
        }
      }
    }
    generalSettings {
      title
      description
    }
  }`
});

const presscoverage = await apolloClient.query({
  query: gql`
    query PressCoverage {
      pressCoverages(first: 64) {
        edges {
          node {
            id
            title
            featuredImage {
              node {
                sourceUrl
                uri
              }
            }
          }
        }
      }
    }`
});

const pressrelease = await apolloClient.query({
  query: gql`
    query PressRelease {
      pressReleases(first: 15) {
        edges {
          node {
            id
            title
            uri
          }
        }
      }
    }`
});

return {
  props: {
    page,
    presscoverage,
    pressrelease
  },
  revalidate: 1,
};
}