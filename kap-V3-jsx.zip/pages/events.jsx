import { getApolloClient } from '../lib/apollo-client';
import { gql } from '@apollo/client'
import Header from "../components/Header"
import Footer from "../components/Footer"
import Hero from "../components/Hero"
import CommonCard from "../components/CommonCard"
import Carousel from "../components/Carousel"
import Intro from "../components/products-services/Intro"
import Head from 'next/head';
import LastCTA from '../components/LastCTA';

export default function PageComponent({ Events }) {

  const baseVar = Events?.data?.data;

  return (
    <> 
       <Header
        title={baseVar?.generalSettings?.title}
        description={baseVar?.generalSettings?.description}
      />
      <Head>
        <title>
          {baseVar?.generalSettings?.title} - {baseVar?.generalSettings?.description}
        </title>
      </Head>
    <main className="content">     
       <Hero
        title={baseVar?.page?.hero?.bannerHeading}
        bgImage={baseVar?.page?.hero?.desktopBanner?.sourceUrl}
        slug={baseVar?.page?.slug}
      />
      </main>
      <Footer copyrightHolder={baseVar?.generalSettings?.title} />
    </>
  );
}

export async function getStaticProps(context) {
  const apolloClient = getApolloClient();

  const data = await apolloClient.query({
    query: gql`
    query Events {
      page(id: "events", idType: URI) {
        title
        slug
        hero {
          desktopBanner {
            sourceUrl
            slug
          }
          bannerHeading
        }
        finalCta {
          finalSectionTitle
          finalSectionDescription
          finalSectionButton {
            title
            url
          }
        }
      }
      generalSettings {
        title
        description
      }
    }`
  });

  return {
    props: {
      Events: { data },
    },
    revalidate: 1,
  };
}