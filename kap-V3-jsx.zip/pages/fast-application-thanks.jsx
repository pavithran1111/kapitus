
const Thankyou = () => {

    return (
        <div className="bg-kapitus">
        <div className="grid p-20 max-w-xl m-auto">
            <h2 className="text-center text-white">Thank you!</h2>
            <p className="text-center text-white">We have received your business loan application and our funding specialists will be reaching out shortly!</p>
        </div>
        </div>
    )
}
export default Thankyou;


