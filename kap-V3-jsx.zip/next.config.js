/** @type {import('next').NextConfig} */
/*const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['ada-kapitus.com']
  }
}

module.exports = nextConfig
*/ 
module.exports = {
  images: {
    domains: ['ada-kapitus.com']
  }
} 