# Next.js Headless WordPress Getting Started Examples

## Setup

See the [setup steps](https://github.com/wpengine/faustjs#quick-start).

## Run it

```bash
npm install
npm run dev
```

[http://localhost:3000]()
