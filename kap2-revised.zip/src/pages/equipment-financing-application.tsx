import { getNextStaticProps, is404 } from '@faustjs/next';
import React, {useState, useEffect} from 'react';
import { GetStaticPropsContext } from 'next';
import { client } from 'client';
import Images from 'next/image'
import EquipmentFastApp from "../components/forms/FastEquipmentFinance"
  
interface MyPageProps {
  username: string;
  password: string;
}
export interface PageProps {
  username: string;
  password: string;
}
export function EquipmentFinancing({username, password }: PageProps) {

  const [data, setData] = useState({})
  const [value, setValue] = useState(false)

  useEffect(() => {
    setData(JSON.parse(localStorage.getItem("equipmentForm")))
    setValue(true)
  }, [])

  return (
    <div className="bg-kapitus py-10 px-10 m-auto w-full">
      <div className="col-span-2 mb-2 text-center text-kapitusblue text-xs font-bold">
      <Images src="/images/kapitus_logo_white.jpg" alt="logo" width={300} height={100} />
      </div>
      <div className="max-w-4xl m-auto text-center">
        <div className='mt-14 pt-10 pl-10 pr-0 pb-36' style={{background:"url(images/inventory-1030x361.jpg) top center no-repeat  #02395e"}}>
        <section>
        <div className='px-6'>
        <h1 className='text-white font-semibold text-3xl text-left'><span>EQUIPMENT FINANCING</span></h1>
        <h2 className='text-white font-semibold text-3xl text-left mb-4'><span>GET APPROVED FAST</span></h2>
        </div>
        </section>
        <section>
        <div className='text-white text-sm text-left px-10'>
        <div className='pb-2'>• 650+ Credit Score 3+ Years in Business Required</div>
        <div>• Truck/Vehicle Financing currently unavailable</div>
        </div>
        </section>
        </div>
      </div>
      {value && <EquipmentFastApp fieldData={data} username={username} password={password} />}
    </div>
  )
}


export default function Page({ username, password }: MyPageProps) {
  return <EquipmentFinancing username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
return getNextStaticProps(context, {
  Page,
  client,
  props: {
    username: process.env.API_USERNAME,
    password: process.env.API_PASSWORD
  },
  notFound: await is404(context, { client }),
});
}