import { getNextStaticProps } from '@faustjs/next';
import { client } from 'client';
import { Footer, Header } from 'components';
import { GetStaticPropsContext } from 'next';
import useInView from "react-cool-inview";
import React, { useEffect, useState, useRef } from "react";
import { useRouter } from "next/router";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import lottie from "lottie-web";
import { FaChevronLeft } from 'react-icons/fa';

export interface PageProps {
  product: string;
}

interface MyPageProps {
  pageUri: string;
}

export function PageComponent({ product }: PageProps) {
  
  const [showlearn, setShowLearn] = useState(true);
  const [button, setButton] = useState(false);
  const router = useRouter();
  const lottieRef = useRef(null)
  const { useQuery } = client;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  let easing = [0.175, 0.85, 0.42, 0.96];
  const transition = { duration: 0.8, ease: easing, type: "spring", damping: 10, mass: 0.75, stiffness: 100 }
  let productname = product.replace('-',' ')

  const productOpen = (event) => {
    setButton(true)
    setShowLearn(false)
    setTimeout(function(){
      router.push(`/product-service/${product}`);
    }, 1)
  }

  const closeModal = () => {
    router.push("/products-offer");
  }

  const onDragEnd = (event, info) => {
    if(info.point.y > 250)
      router.push("/products-offer");
  }

  useEffect(() => {
    var animDuration = 7000;
    const anim = lottie.loadAnimation({
      container: lottieRef.current,
      renderer: "svg",
      loop: false,
      autoplay: false,
      animationData: require('../../components/lottie-image/tick.json'),
      initialSegment: [35, 200],
    });

    const animatebodymovin = (duration, scrollY) => {
      const scrollPosition = scrollY * 3;
      const maxFrames = anim.totalFrames;
      const frame = (maxFrames / 100) * (scrollPosition / (duration / 100));
      anim.goToAndStop(frame, true);
    }

    document.addEventListener('touchmove', function(e) {
      animatebodymovin(animDuration, e.changedTouches[0].pageY);
    }, false);

    document.addEventListener('touchcancel', function(e) {
      animatebodymovin(animDuration, e.changedTouches[0].pageY);
    }, false);
    
    return () => {
      anim.destroy();
    }
  }, [])
 
  const buttonVariants = {
    ini: { y: 400, opacity: 0, transition: { delay: 0.3, duration: 0.3, ease: easing } },
    enter: { y: 0, opacity: 1, transition: { delay: 0.3, duration: 0.5, ease: easing } }
  };
  const titleVariants = {
    initial: { y: -700, transition: { delay: 0.7, duration: 0.3, ease: easing } },
    animate: { y: 0, transition: { delay: 0.7, duration: 0.9, ease: easing } },
  };
  const contentBlockVariants = {
    initial: {
      opacity: 0,
      y: 200,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.7,
        delay: 0.3,
        type: "spring", damping: 30, mass: 0.95, stiffness: 100
      }
    }
  }
  return (
    <AnimatePresence>
      {showlearn && (<>
      <motion.div 
        initial={{ y: -900, opacity: 0 }} animate={{ y: 0, opacity: 1,transition: { delay: .5, duration: .5}}} className="grid grid-cols-3 gap-4 fixed w-full" /*style={{zIndex: -50}}*/>
        <div></div>
        <motion.div animate={{ x: 200, opacity: 1, transition: { delay: 0.1 }}}>
          <div className="fixed w-1/3 hidden" ref={lottieRef}></div>
        </motion.div>
      </motion.div>
      <motion.div 
        initial="initial" 
        animate="animate"
        whileTap={{ cursor: "grabbing" }}
        whileDrag={{ scale: .8, cursor: "grabbing" }} 
        dragElastic={0.5}
        dragTransition={{ bounceStiffness: 600, bounceDamping: 20 }}
        drag="y" 
        dragConstraints={{ top: 0, bottom:0 }} 
        onDragEnd={onDragEnd}
        className="overlay1"
        >
        <motion.div 
          className="grid fixed z-40 cursor-pointer text-white place-items-center w-full h-12 bg-kapitus capitalize text-lg" 
          onClick={closeModal} 
          initial={{ y: -350, opacity: 0 }} 
          animate={{ y: 0, opacity: 1, 
          transition: { delay: .3, ...transition }}}
        >
        <div className="absolute left-0 pl-6"><FaChevronLeft size="20" /></div>
          <motion.div initial="initial" animate="animate" exit="exit" variants={titleVariants}>{productname}</motion.div>
        </motion.div>
        <motion.div className="flex-col justify-center items-center z-50 overflow-y-auto">
          <Link href="/products-offer"><a>
            <motion.img layoutId={`${product}`} className="w-full z-50 object-cover pt-12" style={{zIndex: 100}} src={"/images/"+product + ".jpg"} />
          </a>
          </Link>
          <motion.div className='h-32 w-32 rounded-lg absolute z-50 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'
            exit={{
                scale: [0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                borderRadius: "100%",
                //delay: 1,
                //duration: 1,
                //ease: "easeInOut",
                backgroundColor: "rgb(115, 181, 100)"
            }}
          />
          <div className="flex flex-wrap">
            <motion.h2 className="h-30 mt-8  ml-4 font-extrabold w-3/5 capitalize" layoutId={`header-${product}`}
            >
              {productname}
            </motion.h2>
            <motion.div 
              className="w-1/3" 
              initial="ini"
              animate="enter" 
              exit="exit"
              variants={buttonVariants}
            >
            <motion.button 
              className="p-0 h-10 mt-6 text-indigo-100 w-11/12 duration-150 bg-kapitusLiteGreen rounded-lg focus:shadow-outline hover:bg-kapitusLiteGreen" disabled={button} onClick={productOpen}>Learn More</motion.button>
            </motion.div>
          </div>
          <motion.div>
            <motion.p variants={contentBlockVariants} className="px-4 py-3">
              Available for both short- and long-term needs. Our business loans provide you with an agreed upon sum of money that you will pay back over a specified amount of time, with interest. The amount of interest paid and the total overall cost will depend on whether you opt for a short-term loan, which typically has a higher interest rate but a lower overall cost or a long-term loan, which tends to have a lower interest rate but a higher overall cost.
            </motion.p>
          </motion.div>
        </motion.div>
      </motion.div>
      </>)}
    </AnimatePresence>
  );
}

export default function Page({ pageUri }: MyPageProps) {
  const { useQuery } = client;
  return <PageComponent product={pageUri[0]} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  const {params : { pageUri } } = context
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      pageUri: pageUri
    },
    //notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}