import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header } from 'components';
import { GetStaticPropsContext } from 'next';
import { useEffect, useState } from "react";
import { client, Page as PageType, PageIdType } from 'client';
import useInView from "react-cool-inview";
import Image from 'next/image'
import { useRouter } from "next/router";
import dynamic from "next/dynamic";
import ErrorComponent from './404' 
import Contactform from "../components/forms/ContactForm"

const formId = {1: 'first', 8: 'last', 2: 'email', 14: 'state', 4: 'company', 9: 'connect', 6: 'message'}
const Map = dynamic(() => import("../components/MapBox"), {
  loading: function ld() {
    return <p>Loading...</p>;
  },
  ssr: false,
});
interface MyPageProps {
  username: string;
  password: string;
}
export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

const Contactus = ({ page, username, password }: PageProps) =>  {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  const router = useRouter();
  //const [data, setData] = useState(null);
  const [show, setShow] = useState(true);
  const [refill, setRefill] = useState(null);

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  /*useEffect(() => {
    //  let refData = {}
      let refillData = {}
      if(Object.entries(props.gfentrydata).length > 0){
          //console.log(props.gfentrydata)
          Object.keys(props.gfentrydata).forEach(function(item, key) {
              if(props.gfentrydata[item] !== '' && !isNaN(item)) {
                  if(item == '6'){
                      let dateevent = props.gfentrydata[item].split('/')
                      dateevent.forEach(function(item1, index) {
                          refillData[formId[6+"."+(index+1)]] = item1
                      })
                  }
                  else {
                      refillData[formId[item]] = props.gfentrydata[item];
                  }
                  // refData[item] = props.gfentrydata[item];
              }
          });
      }
      //refData['form_id'] = '33'
      //setData(refData);
      setRefill(refillData)
  }, [props.gfentrydata])*/

  const onDragEnd = (event, info) => {
    const shouldClose = info.velocity.y >= 225 && info.point.y > 225
    if (shouldClose) {
        setShow(false)
        router.push("/product-service/business-loans")
    }
  }

  return (
    <> 
    <Header
      title={`${page?.title()} - ${generalSettings.title}`}
      description={generalSettings.description}
      metaDesc={page?.seo?.metaDesc}
      opengraphTitle={page?.seo?.metaTitle}
      targetKeywords={page?.seo?.targetKeywords}
    />
    <div className="bg-gray-100">
    <div className="mx-auto overflow-hidden">
      <div className="md:flex bg-footer">
      <div className="relative w-full overflow-hidden">
        <Image alt="contact-us" priority src="/images/contact-us.webp" layout="fill" className="w-full h-full" />
        <div className="absolute w-full py-24 bottom-0 inset-x-0  text-kapitus text-xl font-bold text-center leading-4">Contact Us</div>
      </div>
      <div className="w-full p-5 px-10 bg-kapitus" id="form1">
        <Contactform entry_id={``} username={username} password={password} /*refill={refill}*/ />                
      </div>
      </div>
      <div className='md:flex'>
        <section ref={observe} className='relative h-96 w-full'>{inView && <Map />}</section>
      </div>
    </div>
    </div>
    <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  )
}

export default function Page({ username, password }: MyPageProps) {
  
  const { usePage } = client;

  const page = usePage({
    id: 'contact-us',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <Contactus page={page} username={username} password={password} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}