import { useEffect, useState } from "react";
import { getNextStaticProps, is404 } from '@faustjs/next';
import { GetStaticPropsContext } from 'next';
import { client } from 'client';
import Images from 'next/image'
import InvoiceFactoringApp from "../components/forms/FastInvoiceFactoring"

export function InvoiceFactoring({}): JSX.Element {
  
  const [data, setData] = useState({})
  const [value, setValue] = useState(false)

  useEffect(() => {
    let val = localStorage.getItem("invoiceForm")
    setData(JSON.parse(val))
    setValue(true)
  }, [])

  return (
    <div className="bg-kapitus py-10 px-10 m-auto w-full">
      <div className="col-span-2 mb-2 text-center text-kapitusblue text-xs font-bold">
      <Images src="/images/kapitus_logo_white.jpg" alt="logo" width={300} height={100} />
      </div>
      <div className="max-w-4xl m-auto text-center">
        <div className="mt-12 pt-10 pl-10 pr-0 pb-36" style={{background:"url(/images/inventory-1030x361.jpg) top center no-repeat #02395e"}}>
        <section>
        <div className="text-white">
        <div className="px-6">
          <h1 className="text-white font-semibold text-3xl text-left"><span>INVOICE FACTORING</span></h1>
          <h2 className="text-white font-semibold text-3xl text-left mb-4"><span>TURN ACCOUNT RECEIVABLES INTO CASH</span></h2>
        </div>
        </div>
        </section>
        <section>
        <div className="text-white text-sm text-left px-10">
        <div className="">• Factoring Lines From $200K – $7 Million</div>
        </div>
        </section>
        </div>
      </div>
      {value && <InvoiceFactoringApp fieldData={data} />}
    </div>
  )
}

export default function Page() {
  return <InvoiceFactoring />; 
}

export async function getStaticProps(context: GetStaticPropsContext) {
return getNextStaticProps(context, {
  Page,
  client,
  notFound: await is404(context, { client }),
});
}