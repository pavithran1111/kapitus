import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header, Advancedhero } from 'components';
import { GetStaticPropsContext } from 'next';
import useInView from "react-cool-inview";
import { client, Page as PageType, PageIdType } from 'client';
import ErrorComponent from './404' 
import LastCTA from 'components/LastCTA';
import TimeLine from 'components/TimeLine';
import Team from 'components/Teams';

interface MyPageProps {
  username: string;
  password: string;
}

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function AboutUS({ page, username, password }: PageProps) {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  return (
    <> 
      <Header
        title={`${page?.title()} - ${generalSettings.title}`}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
      />
      {/* FIRST SECTION OF PAGE */}
      <Advancedhero
        indexTitle=""
        title={page?.heroAdvanced?.advancedBannerEditor}
        buttonText=""
        buttonURL=""
        bgImage={page?.heroAdvanced?.desktopBanner?.mediaItemUrl}
        alt={page?.heroAdvanced?.desktopBanner?.altText}
        column='one'
        slug={page?.slug}
      />

      <section ref={observe}>{inView && <LastCTA
        title={page?.finalCta?.finalSectionTitle} 
        subtitle={''}
        description={page?.finalCta.finalSectionDescription}
        buttonText={page?.finalCta?.finalSectionButton?.title}
        buttonURL={page?.finalCta?.finalSectionButton?.url}
      />}</section>

      <section ref={observe}>
      {inView && <TimeLine /> }
      </section>
      <section ref={observe}>
      {inView && <Team />}
      </section>
      <section ref={observe}>
        {inView && <LastCTA
          title={page?.finalCta?.finalSectionTitle} 
          subtitle={''}
          description={page?.finalCta.finalSectionDescription}
          buttonText={page?.finalCta?.finalSectionButton?.title}
          buttonURL={page?.finalCta?.finalSectionButton?.url}
        />}
      </section>
      <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  
  const { usePage } = client;

  const page = usePage({
    id: 'about-us',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <AboutUS page={page} username={username} password={password} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}