import { getNextStaticProps, is404 } from '@faustjs/next';
import React, { useEffect, useState } from "react";
import { GetStaticPropsContext } from 'next';
import { client } from 'client';
import Images from 'next/image'
import Fastapp from "../components/forms/FastApp"
import Popup from "../components/forms/PopUp";

interface MyPageProps {
  username: string;
  password: string;
}
export interface PageProps {
  username: string;
  password: string;
}

export function Applynow({username, password }: PageProps) {

  const [data, setData] = useState({})
  const [value, setValue] = useState(false)
  const [trigger, setTrigger] = useState(false)
  
  useEffect(() => {
    setTimeout(() => {
      //setTrigger(true)
      //document.body.style.overflowY='hidden'
    }, 5000)
    
    let val = localStorage.getItem("shortForm")
    setData(JSON.parse(val))
    setValue(true)
  }, [trigger])

  return (
    <>
    <div className="bg-kapitus py-10 px-10 m-auto w-full">
      <div className="col-span-2 mb-2 text-center text-kapitusblue text-xs font-bold">
        <Images src="/images/kapitus_logo_white.jpg" alt="logo" priority layout="intrinsic" width={300} height={90} />
      </div>
      <div className={`max-w-4xl m-auto ${trigger ? `opacity-50`:``}`}>
        <div className="mt-10 px-8 py-20" style={{background:"url(/images/form-banner.jpg) center center"}}>
        <section>
        <div>
        <h1 className="text-left"><span className="text-white text-xl font-bold">BUSINESS LOANS GET APPROVED FAST</span></h1>
        <h2 className="text-left"><span className="text-white text-xl font-bold">GET APPROVED FAST</span></h2>
        </div>
        </section>
        <section>
        <div className="pl-4 mt-4">
        <div className="text-left"><span className="text-white">• 250K in Average Annual Revenue Required</span></div>
        <div className="text-left"><span className="text-white">• 2+ Years in Business Required</span></div>
        <div className="text-left"><span className="text-white">• 625 Credit Score</span></div>
        </div>
        </section>
        </div>
        {value && <Fastapp fieldData={data} username={username} password={password} />}
      </div>
    </div>
{/*       <Popup trigger={trigger} setTrigger={setTrigger}>
      </Popup> */}
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
    return <Applynow username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}