import { getNextStaticProps, is404 } from '@faustjs/next';
import React, { useEffect, useState } from "react";
import { GetStaticPropsContext } from 'next';
import styles from 'scss/components/CaliforniaForm.module.scss';
import { client } from 'client';
import Images from 'next/image'
import Head from 'next/head'
import CaliforniaForm from "../components/forms/CaliforniaForm"
import { useRouter } from "next/router";

interface MyPageProps {
  username: string;
  password: string;
}
export interface Props {
  username: string;
  password: string;
}

export function DataPrivacyRequest({ username, password }: Props) {
const router = useRouter();
const [trigger, setTrigger] = useState(false)
const credentials = {user: 'kapitus', password: 'kapitus@2021' }

useEffect(() => {
  setTimeout(() => {
    //setTrigger(true)
    //document.body.style.overflowY='hidden'
  }, 5000)
}, [trigger])

return (
  <>
    <Head>
    <title>California Form - Kapitus</title>
    <meta name="theme-color" content="#73b564" />
  </Head>
  <div className="py-10 px-10 m-auto w-full">
    <div className="col-span-2 mb-2 text-center text-kapitusblue text-xs font-bold">
      <Images src="/images/favicon.png" alt="logo" width={40} height={40} />
    </div>
    <div className="max-w-3xl m-auto">
      <section>
      <div className="pt-4 text-center">
          <span className="text-4xl">Kapitus California Consumer Privacy Act Request Page</span>
      </div>
      <hr className={styles.hori} />
      </section>
      <section>
      <div className="pl-4 mt-4 text-center">
        <p>250K in Average Annual Revenue Required</p>
        <h5>Please fill out as much of the below information as possible to better locate your records</h5>
      </div>
      </section>
      <CaliforniaForm fieldData={router.query} username={username} password={password} />
    </div>
  </div>
  </>
);
}

export default function Page({ username, password }: MyPageProps) {
  return <DataPrivacyRequest username={username} password={password} />; 
}

export async function getStaticProps(context: GetStaticPropsContext) {
return getNextStaticProps(context, {
  Page,
  client,
  props: {
    username: process.env.API_USERNAME,
    password: process.env.API_PASSWORD
  },
  notFound: await is404(context, { client }),
});
}