import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header, CommonCard,Carousel } from 'components';
import SuccessSlider from "../components/SuccessSlider"
import { GetStaticPropsContext } from 'next';
import { client, Page as PageType, PageIdType } from 'client';
import ErrorComponent from './404' 
import LastCTA from 'components/LastCTA';

interface MyPageProps {
  username: string;
  password: string;
}
export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function PageComponent({ page, username, password }: PageProps) {
  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;
  const carouselHero = [page?.carouselHero?.carouselGroup1, page?.carouselHero?.carouselGroup2, page?.carouselHero?.carouselGroup1, page?.carouselHero?.carouselGroup3]
  const cardGroup = [page?.CardRows?.cardGroup1, page?.CardRows?.cardGroup2, page?.CardRows?.cardGroup3 ]
  const cardGroup1 = [page?.CardRows?.cardGroup4, page?.CardRows?.cardGroup5, page?.CardRows?.cardGroup6 ]
  const cardGroup2 = [page?.CardRows?.cardGroup7, page?.CardRows?.cardGroup8, page?.CardRows?.cardGroup9 ]
  const carousel = [page?.carousel?.carouselGroup1, page?.carousel?.carouselGroup2, page?.carousel?.carouselGroup3]

  return (
    <> 
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
      />
       <SuccessSlider carouselData={carouselHero} />

      <CommonCard
        cardMainTitle={page?.CardRows?.cardMainTitle}
        cardData={cardGroup}
        cardData1={cardGroup1}
        cardData2={cardGroup2}
      />

    <Carousel data={carousel} />

    <LastCTA
    title={page?.finalCta?.finalSectionTitle} 
    subtitle={''}
    description={page?.finalCta.finalSectionDescription}
    buttonText={page?.finalCta?.finalSectionButton?.title}
    buttonURL={page?.finalCta?.finalSectionButton?.url}
  />
     
      <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: page?.content() ?? '' }} />
        </div>
      </main>
      <Footer copyrightHolder={generalSettings.title} username={username} password={password} />
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  
  const { usePage } = client;

  const page = usePage({
    id: 'success-stories',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <PageComponent page={page} username={username} password={password} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}