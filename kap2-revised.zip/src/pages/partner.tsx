import { getNextStaticProps, is404 } from '@faustjs/next';
import styles from 'scss/pages/partner.module.scss';
import { Footer, Header, Hero, Advancedhero, CommonCard, PartnerData } from 'components';
import { GetStaticPropsContext } from 'next';
import useInView from "react-cool-inview";
import { client, Page as PageType, PageIdType } from 'client';
import ErrorComponent from './404' 
import LastCTA from 'components/LastCTA';

interface MyPageProps {
  username: string;
  password: string;
}

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}
 
export function PageComponent({ page, username, password }: PageProps) {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  const cardGroup = [page?.CardRows?.cardGroup1, page?.CardRows?.cardGroup2, page?.CardRows?.cardGroup3 ]
  const cardGroup1 = [page?.CardRows?.cardGroup4, page?.CardRows?.cardGroup5, page?.CardRows?.cardGroup6 ]
  const cardGroup2 = [page?.CardRows?.cardGroup7, page?.CardRows?.cardGroup8, page?.CardRows?.cardGroup9 ]
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  return (
    <> 
      <Header
        title={`${page?.title()} - ${generalSettings.title}`}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
      />
      {/* FIRST SECTION OF PAGE */}
      {page?.heroBasic?.basicBannerEditor ? 
        (<Hero
          indexTitle=''
          title={page?.heroBasic?.basicBannerEditor}
          buttonText="SIGN UP"
          buttonURL="#"
          bgImage={page?.heroBasic?.desktopBanner?.mediaItemUrl}
          alt={page?.heroBasic?.desktopBanner?.altText}
          slug={page?.slug}
          username={username}
          password={password}
        />) : (<Advancedhero
          indexTitle=''
          title={page?.heroAdvanced?.advancedBannerEditor}
          buttonText="SIGN UP"
          buttonURL="#"
          bgImage={page?.heroAdvanced?.desktopBanner?.mediaItemUrl}
          alt={page?.heroAdvanced?.desktopBanner?.altText}
          column='one'
          slug={page?.slug}
          username={username}
          password={password}
        />)
      }

      <section ref={observe}>
        {inView && <CommonCard
          cardMainTitle={page?.CardRows?.cardMainTitle}
          cardData={cardGroup}
          cardData1={cardGroup1}
          cardData2={cardGroup2}
      />}
      </section>

      <section ref={observe}>
        {inView && 
        <><div className={styles.horizontal} />
        <div className={styles.buttonCenter}>
        <a className={styles.buttonLink}>
          <button className={styles.link}>NONE REALLY FIT</button>
        </a>
        </div></>}
      </section>

      <section ref={observe}>
        {inView && <PartnerData
      accordianMainTitle={page?.accordion?.accordionMainTitle}
      accordianMainImage={page?.accordion?.accordionMainImage?.sourceUrl()}
      />}
      </section>

      <section ref={observe}>
        {inView && <LastCTA
        title={page?.finalCta?.finalSectionTitle} 
        subtitle={''}
        description={page?.finalCta.finalSectionDescription}
        buttonText={page?.finalCta?.finalSectionButton?.title}
        buttonURL={page?.finalCta?.finalSectionButton?.url}
      /> }
      </section>
      <section ref={observe}>
      {inView && 
      <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: page?.content() ?? '' }} />
        </div>
      </main>}
      </section>
      <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  
  const { usePage } = client;

  const page = usePage({
    id: 'partner',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <PageComponent page={page} username={username} password={password} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}