import { getNextStaticProps, is404 } from '@faustjs/next';
import { Hero } from 'components';
import CustomHeader from 'components/CustomHeader'
import { GetStaticPropsContext } from 'next';
import { client, Page as PageType, PageIdType } from 'client';
import useInView from "react-cool-inview";
import ErrorComponent from './404' 

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
}

export function PageComponent({ page }: PageProps) {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });
 
  return (
    <> 
      <CustomHeader title={`${page?.title()} - ${generalSettings.title}`} slug={page?.slug} headerData={page?.uniqueHeader} />  
      <Hero
          indexTitle=''
          title={page?.heroBasic?.basicBannerEditor}
          bgImage={page?.heroBasic?.desktopBanner?.mediaItemUrl}
          alt={page?.heroBasic?.desktopBanner?.altText}
          type="cobrand"
          slug={page?.slug}
        />
        <section ref={observe}>
          {inView &&<div className="" 
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{ __html: page?.cobrandPage?.cobrandBody ?? '' }}
          />}
      </section>
     </>
  );
}

export default function Page() {
  
  const { usePage } = client;

  const page = usePage({
    id: 'investable',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <PageComponent page={page} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    notFound: await is404(context, { client }),
  });
}