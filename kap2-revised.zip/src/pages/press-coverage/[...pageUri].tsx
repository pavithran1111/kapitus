import { getNextStaticProps } from '@faustjs/next';
import { client, PressCoverage as PressCoverageType } from 'client';
import { Footer, Header, PressCoverage } from 'components';
import { GetStaticPropsContext } from 'next';
import useInView from "react-cool-inview";

export interface PressCoverageTypeProps {
  presscoverage: PressCoverageType | PressCoverageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

interface MyPageProps {
  pageUri: string;
  username: string;
  password: string;
}

export function PostComponent({ presscoverage, username, password }: PressCoverageTypeProps) {
  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={presscoverage?.seo?.metaDesc}
        opengraphTitle={presscoverage?.seo?.metaTitle}
        targetKeywords={presscoverage?.seo?.targetKeywords}
      />

      <section ref={observe}>{inView && <PressCoverage presscoverage={presscoverage} />}</section>

      <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  );
}

export default function Page({ pageUri, username, password }: MyPageProps) {

  const { useQuery } = client;
  const presscoverage = useQuery()?.pressCoverages({where: {name:pageUri[0]}}).nodes
  return <PostComponent presscoverage={presscoverage[0]} username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  const {params : { pageUri } } = context
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      pageUri: pageUri,
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    //notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}
