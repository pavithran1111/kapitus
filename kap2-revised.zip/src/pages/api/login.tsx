/*import cookie from 'cookie'


export default (req, res)=>{

    res.setHeader('Set-Cookie', cookie.serialize('wordpress_sec_0e19e905c1fa4ba5b111fec4e52b0715', req.body.token, {
        httpOnly: true,
        secure: true,
        maxAge: 60 * 60,
        sameSite: "strict",
        path : '/',
    } ));

    res.statusCode = 200;
    res.json( {success: true});
}*/

import cookie from "cookie";

const login = (req: { body: { token: any; }; }, res: { setHeader: (arg0: string, arg1: any) => void; statusCode: number; json: (arg0: { success: boolean; }) => void; }) => {
  res.setHeader(
    "Set-Cookie",
    cookie.serialize("wordpress_sec_0e19e905c1fa4ba5b111fec4e52b0715", req.body.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV !== "development",
      maxAge: 60 * 60,
      //domain: "https://wp.kapstaging.com",
      //sameSite: "strict",
      path: "/",
    })
  );
  res.statusCode = 200;
  res.json({ success: true });
};

export default login;