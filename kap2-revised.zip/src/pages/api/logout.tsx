import cookie from 'cookie'


const logout = (_req: any, res: { setHeader: (arg0: string, arg1: any) => void; statusCode: number; json: (arg0: { success: boolean; }) => void; })=>{
    res.setHeader('Set-Cookie', cookie.serialize('wordpress_sec_0e19e905c1fa4ba5b111fec4e52b0715', "", {
        httpOnly: true,
        secure: false,
        expires: new Date(0),
        sameSite: "strict",
        path : '/wp-admin',
    } ));

    res.statusCode = 200;
    res.json( {success: true});
}

export default logout;