import 'faust.config';
import { apiRouter } from '@faustjs/core/api';

export default apiRouter;
