import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header, Hero, Advancedhero, Intro, CommonCard, Carousel, MediaCenter, Relatedblogs } from 'components';
import { GetStaticPropsContext } from 'next';
import { client, Page as PageType, PressCoverage, PressRelease } from 'client';
import ErrorComponent from './404'
import LastCTA from 'components/LastCTA';
import useInView from "react-cool-inview";

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  slug: string;
  presscoverage: PressCoverage[];
  pressrelease: PressRelease[];
  username: string;
  password: string;
}

interface MyPageProps {
  pageUri: string;
  username: string;
  password: string;
}

export function PageComponent({ page, slug, presscoverage, pressrelease, username, password }: PageProps) {
  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  const cardGroup = [page?.CardRows?.cardGroup1, page?.CardRows?.cardGroup2, page?.CardRows?.cardGroup3 ]
  const cardGroup1 = [page?.CardRows?.cardGroup4, page?.CardRows?.cardGroup5, page?.CardRows?.cardGroup6]
  const cardGroup2 = [page?.CardRows?.cardGroup7, page?.CardRows?.cardGroup8, page?.CardRows?.cardGroup9]
  const carousel = [page?.carousel?.carouselGroup1, page?.carousel?.carouselGroup2, page?.carousel?.carouselGroup3]
  //console.log(page?.seo?.proSchemas)
  
  return (
    <> 
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        // metaKeywords={page?.seo?.metaKeywords}
        targetKeywords={page?.seo?.targetKeywords}
        proschema={page?.seo?.proSchemasManual}
     />
      {/* FIRST SECTION OF PAGE */}
      {page?.heroBasic?.basicBannerEditor ? 
        (<Hero
          indexTitle=''
          title={page?.heroBasic?.basicBannerEditor}
          bgImage={page?.heroBasic?.desktopBanner?.mediaItemUrl}
          buttonText="SIGN UP"
          buttonURL="#"
          alt={page?.heroBasic?.desktopBanner?.altText}
          slug={page?.slug}
          username={username}
          password={password}
        />) : (<Advancedhero
          indexTitle=''
          title={page?.heroAdvanced?.advancedBannerEditor}
          bgImage={page?.heroAdvanced?.desktopBanner?.mediaItemUrl}
          alt={page?.heroAdvanced?.desktopBanner?.altText}
          column='one'
          slug={page?.slug}
          username={username}
          password={password}
        />)
      }

      {page?.intro?.introTitle && <Intro introTitle={page?.intro?.introTitle} subtitle={page?.intro?.introDescription} />}
      {page?.CardRows?.cardGroup1?.cardTitle && <CommonCard cardMainTitle={page?.CardRows?.cardMainTitle} cardData={cardGroup} cardData1={cardGroup1} cardData2={cardGroup2} />}

      {carousel[0]?.companyTitle && <Carousel data={carousel} />}

      {slug == 'media-center' && <MediaCenter presscoverage={presscoverage} pressrelease={pressrelease} />}

      {page?.finalCta?.finalSectionTitle && 
        <section ref={observe}>{inView && (<LastCTA
          title={page?.finalCta?.finalSectionTitle} 
          subtitle={''}
          description={page?.finalCta.finalSectionDescription}
          buttonText={page?.finalCta?.finalSectionButton?.title}
          buttonURL={page?.finalCta?.finalSectionButton?.url}
        />)}
        </section>
      }

      <main className="content content-single">
        <div className="wrap" ref={observe}>
          {inView && (<div dangerouslySetInnerHTML={{ __html: page?.content() ?? '' }} />)}
        </div>
      </main>

      {page?.relatedBlogPosts?.relatedBlogEditor && 
      <section ref={observe}>
        {inView && (<Relatedblogs relatedblogs={page?.relatedBlogPosts} />)}
      </section>
      }
      <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} />}</section>
    </>
  );
}

export default function Page({ pageUri, username, password }: MyPageProps) {
  const { usePage, useQuery } = client;
  const page = usePage();

  const presscoverage = useQuery().pressCoverages({first: 300 })?.nodes;
  const pressrelease = useQuery().pressReleases({first: 100 })?.nodes;
  if(Object.entries(page).length)
    return <PageComponent page={page} slug={pageUri[0]} presscoverage={presscoverage} pressrelease={pressrelease} username={username} password={password} />;
  else 
    return <ErrorComponent />
}

export async function getStaticProps(context: GetStaticPropsContext) {
  const {params : { pageUri } } = context
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      pageUri: pageUri,
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}