import 'faust.config';
import { FaustProvider } from '@faustjs/next';
// import 'normalize.css/normalize.css';
import React from 'react';
import 'scss/main.scss';
import { client } from 'client';
import type { AppProps } from 'next/app';

import TagManager from 'react-gtm-module'
import {useEffect } from 'react';
 
const tagManagerArgs = {
  gtmId: 'GTM-KKZPM4T'
}

export default function MyApp({ Component, pageProps, router }: AppProps) {
  useEffect(() => {
    TagManager.initialize({ gtmId: 'GTM-KKZPM4T' });
  }, []);

  return (
    <>
      <FaustProvider client={client} pageProps={pageProps}>
        <Component {...pageProps} key={router.asPath} />
      </FaustProvider>
    </>
  );
}
