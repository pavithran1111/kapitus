import { getNextStaticProps, is404 } from '@faustjs/next';
import Head from 'next/head';
import { Header, Footer, Posts, Pagination } from 'components';
import { GetStaticPropsContext } from 'next';
import { useRouter } from 'next/router';
import { client } from 'client';
import styles from 'scss/components/Posts.module.scss';
import RecentPost from "../../../components/RecentPost";
import Category from "../../../components/Category";
import SearchBlogs from "../../../components/SearchBlogs";
import SubscribeBlog from "../../../components/forms/SubscribeBlog";

const POSTS_PER_PAGE = 9;
const RECENT_POST_COUNT = 5;

interface MyPageProps {
  username: string;
  password: string;
}

export default function Page({ username, password }: MyPageProps) {
  const { useQuery, usePosts, useCategory } = client;
  const { query = {} } = useRouter();
  const { postSlug, postCursor, categorySlug, paginationTerm, categoryCursor } = query;
  const generalSettings = useQuery().generalSettings;
  const category = useCategory();
  const isBefore = paginationTerm === 'before';
  
  const categoryList = useQuery()
  const categories = categoryList.categories;
  const categ = categories({first: 50})

  const recentPosts = usePosts({
    after: !isBefore ? (postCursor as string) : undefined,
    before: isBefore ? (postCursor as string) : undefined,
    first: !isBefore ? RECENT_POST_COUNT : undefined,
    last: isBefore ? RECENT_POST_COUNT : undefined,
  });
  
  const posts = usePosts({
    after: !isBefore ? (categoryCursor as string) : undefined,
    before: isBefore ? (categoryCursor as string) : undefined,
    first: !isBefore ? POSTS_PER_PAGE : undefined,
    last: isBefore ? POSTS_PER_PAGE : undefined,
  });

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
      />

      <Head>
        <title>Posts - {generalSettings?.title}</title>
      </Head>

      <main className="content content-single">
        <div className="blogWrap">
        <div className="blogContainer">
        <section id={styles.post_list}>
            <h2>Category: {category?.name}</h2>
            <Posts posts={posts.nodes} />

            <Pagination
              pageInfo={posts.pageInfo}
              basePath={`/category/${categorySlug}`}
            />
        </section>
        </div>
        <div className="blogNav">
          <SearchBlogs />
          <RecentPost  />
          <SubscribeBlog username={username} password={password} />
          <Category categories={categ?.nodes} />
        </div>
        </div>
      </main>
      <Footer copyrightHolder={generalSettings.title} username={username} password={password} />
    </>
  );
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}
