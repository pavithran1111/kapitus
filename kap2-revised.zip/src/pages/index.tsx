import { getNextStaticProps } from '@faustjs/next';
import { useState } from 'react';
import { GetStaticPropsContext } from 'next';
import React, { useEffect } from 'react';
import { Hero, Footer, Header } from 'components';
import styles from 'scss/pages/home.module.scss';
import Card from '../components/Card';
import { Page as PageType, client, PageIdType } from 'client';
import Typewriter from 'typewriter-effect';
import useInView from "react-cool-inview";

export function TypingEffect() {
  const [state] = useState ({
    title: '',
    titleTwo: '',
    titleThree: '',
  })

  return (
    <div className={styles.text}>
      <div className='title'>{state.title}</div>
      <div className='titleTwo'>{state.titleTwo}</div>
      <div className='titleThree'>{state.titleThree}</div>
      <Typewriter
        options={{ 
          cursor: "",
          autoStart: true,
          loop: true,
          delay: 70,
          strings: [
            "run your business",
            "grow your business",
            "secure your business",
            "renovate",
            "get new equipments",
            "pay my taxes",
            "move to a new locations",
            "purchase inventory",
            "run marketing campaigns",
          ],
        }}
      />
    </div>
  );
}

interface MyPageProps {
  username: string;
  password: string;
}

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function PageComponent({ page, username, password }: PageProps) {

  const { useQuery } = client;
  
  const generalSettings = useQuery().generalSettings;

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });
  //const img1 = page?.CardRows?.cardGroup1?.cardIcon?.sourceUrl() && page?.CardRows?.cardGroup1?.cardIcon?./sourceUrl().substring(page?.CardRows?.cardGroup1?.cardIcon?.sourceUrl().lastIndexOf('/')+1)
  //const img2 = page?.CardRows?.cardGroup2?.cardIcon?.sourceUrl() &&  page?.CardRows?.cardGroup2?.cardIcon?.sourceUrl().substring(page?.CardRows?.cardGroup3?.cardIcon?.sourceUrl().lastIndexOf('/')+1)
  //const img3 = page?.CardRows?.cardGroup3?.cardIcon?.sourceUrl() &&  page?.CardRows?.cardGroup3?.cardIcon?.sourceUrl().substring(page?.CardRows?.cardGroup3?.cardIcon?.sourceUrl().lastIndexOf('/')+1)
  


  useEffect(()=> {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://cdn.trustindex.io/loader.js?09a5ee4135268498715860a5eb";
    document.getElementById("new").append(s);
  },[])

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
        proschema={page?.seo?.proSchemasManual}
      />
      <main className="content">
        <Hero
          indexTitle="Business Loan Financing to:"
          title=''
          buttonText="GET STARTED"
          buttonURL="https://example.com"
          //  bgImage="/images/headless_hero_background.webp"
          // bgImage="/images/tablet.webp"
          bgImage='https://res.cloudinary.com/dsfu88hae/image/upload/v1647389853/NewMedia/linkedin-sales-solutions-VtKoSy_XzNU-unsplash_vrlzaa.webp'
          alt={page?.heroAdvanced?.desktopBanner?.altText}
          id={styles.home_hero}
          slug="home"
          username={username}
          password={password}
        >
        <TypingEffect />
        </Hero>

         {/* <section className="container" ref={observe}>
          {inView && (<Script 
              defer 
              async 
              strategy="beforeInteractive"
              src="https://cdn.trustindex.io/loader.js?09a5ee4135268498715860a5eb"
          />)}
        </section> */}

<section className="content" ref={observe}>
<div id="new"></div>
</section>

        <section className="content" ref={observe}>
        {inView && (
        <Card
            cardMainTitle={page?.CardRows?.cardMainTitle} 
            cardGroupImg1={page?.CardRows?.cardGroup1?.cardIcon?.sourceUrl() ?? ''}            
            cardGroupTitle1={page?.CardRows?.cardGroup1?.cardTitle}
            cardGroupBtn1={page?.CardRows?.cardGroup1?.cardButton?.url ?? ''}

            cardGroupImg2={page?.CardRows?.cardGroup2?.cardIcon?.sourceUrl() ?? ''}
            cardGroupTitle2={page?.CardRows?.cardGroup2?.cardTitle}
            cardGroupBtn2={page?.CardRows?.cardGroup2?.cardButton?.url ?? ''}

            cardGroupImg3={page?.CardRows?.cardGroup3?.cardIcon?.sourceUrl() ?? ''}
            cardGroupTitle3={page?.CardRows?.cardGroup3?.cardTitle}
            cardGroupBtn3={page?.CardRows?.cardGroup3?.cardButton?.url ?? ''}
        />)}
        </section>
      </main>
      <section>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  )
}
export default function Page({ username, password }: MyPageProps) {

  const { usePage  } = client;
  const page = usePage({
    id: '21596',
    idType: PageIdType.DATABASE_ID,
  });
  
  return <PageComponent page={page} username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    client,
  });
}
