import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header, Hero, ProductsServices } from 'components';
import { GetStaticPropsContext } from 'next';
import Head from 'next/head';
import { client, ProductsService as ProductsServiceType } from 'client';

export interface ProductsServiceProps {
  products: ProductsServiceType | ProductsServiceType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

interface MyPageProps {
  username: string;
  password: string;
}

export function ProductsComponent({ products, username, password }: ProductsServiceProps) {
  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={products?.seo?.metaDesc}
        opengraphTitle={products?.seo?.metaTitle}
        targetKeywords={products?.seo?.targetKeywords}
      />
      <Head>
        <title>
          {products?.title()} - {generalSettings.title}
        </title>
      </Head>
     <ProductsServices productsService={products} username={username} password={password} />
      <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: products?.content() ?? '' }} />
        </div>
      </main>
      <Footer copyrightHolder={generalSettings.title} />
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  
/*   const { usePage } = client;
  const products = usePage(); */
  return <ProductsComponent products={null} username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}
