import { getNextStaticProps, is404 } from '@faustjs/next';
import { Advancedhero, Footer, Header } from 'components';
import { GetStaticPropsContext } from 'next';
import { client, TeamMember as TeamMemberType } from 'client';

interface MyPageProps {
  username: string;
  password: string;
}
export interface TeamMemberProps {
  team: TeamMemberType | TeamMemberType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function TeamComponent({ team, username, password }: TeamMemberProps) {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;
  return (
    <>
      <Header
        title={`${team?.title()} - ${generalSettings.title}`}
        description={generalSettings.description}
        metaDesc={team?.seo?.metaDesc}
        opengraphTitle={team?.seo?.metaTitle}
        targetKeywords={team?.seo?.targetKeywords}
      />

      <Advancedhero
      indexTitle=''
        // title={page?.title()}
        // bgImage={page?.featuredImage.node.sourceUrl()}
        //  title={page?.standardPage?.heroTitle}
        title={team?.title()}
        column='one'
        slug={team?.slug}
   
    />

      <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: team?.content() ?? '' }} />
        </div>
      </main>

      <Footer copyrightHolder={generalSettings.title} username={username} password={password} />
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
/*   const { usePage } = client;
  const team = usePage(); */
  return <TeamComponent team={null} username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

/*export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}*/
