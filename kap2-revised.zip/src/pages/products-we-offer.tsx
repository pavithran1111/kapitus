import { getNextStaticProps, is404 } from '@faustjs/next';
import { Footer, Header, Advancedhero, Intro, CommonCard, Carousel, SecondaryMenu } from 'components';
import SecondaryMobileMenu from "../components/SecondaryMobileMenu"
import { GetStaticPropsContext } from 'next';
import { client, Page as PageType, PageIdType } from 'client';
import useInView from "react-cool-inview";
import ErrorComponent from './404' 
import LastCTA from 'components/LastCTA';
//import Products from 'components/MobileProduct/Products';

interface MyPageProps {
  username: string;
  password: string;
}

export interface PageProps {
  page: PageType | PageType['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function PageComponent({ page, username, password }: PageProps) {

  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  const cardGroup = [page?.CardRows?.cardGroup1, page?.CardRows?.cardGroup2, page?.CardRows?.cardGroup3 ]
  const cardGroup1 = [page?.CardRows?.cardGroup4, page?.CardRows?.cardGroup5, page?.CardRows?.cardGroup6]
  const cardGroup2 = [page?.CardRows?.cardGroup7, page?.CardRows?.cardGroup8, page?.CardRows?.cardGroup9]
  const carousel = [page?.carousel?.carouselGroup1, page?.carousel?.carouselGroup2, page?.carousel?.carouselGroup3]

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  return (
    <> 
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
      />
      <SecondaryMenu title="" />
      <SecondaryMobileMenu title={page?.slug} />
      {/* FIRST SECTION OF PAGE */}     
      <Advancedhero
        title={page?.heroAdvanced?.advancedBannerEditor}
        indexTitle=''
        bgImage={page?.heroAdvanced?.desktopBanner?.sourceUrl()}
        alt={page?.heroAdvanced?.desktopBanner?.altText}
        disclaimer={page?.heroAdvanced?.disclaimer}
        slug={page?.slug}
        type="reviews"
        username={username}
        password={password}
      />
      <section ref={observe}>
        {inView && <Intro 
        introTitle={page?.intro?.introTitle}
        subtitle={page?.intro?.introDescription}
        />}
      </section>
      
      <section ref={observe}>
        {inView && <CommonCard
          cardMainTitle={page?.CardRows?.cardMainTitle}
          cardData={cardGroup}
          cardData1={cardGroup1}
          cardData2={cardGroup2}
        />}
      </section>
      <section ref={observe}>
        {inView && <Carousel data={carousel} />}
      </section>
      
      <section ref={observe}>
        {inView && <LastCTA
          title={page?.finalCta?.finalSectionTitle} 
          subtitle={''}
          description={page?.finalCta.finalSectionDescription}
          buttonText={page?.finalCta?.finalSectionButton?.title}
          buttonURL={page?.finalCta?.finalSectionButton?.url}
        />}
      </section>
      {/* Mobile Products */}
      {/* <Products /> */}
      <section ref={observe}>{inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}</section>
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  
  const { usePage } = client;

  const page = usePage({
    id: 'products-we-offer',
    idType: PageIdType.URI,
  });

   if(Object.entries(page).length)
    return <PageComponent page={page} username={username} password={password} />;
   else 
    return <ErrorComponent /> 
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    client,
    notFound: await is404(context, { client }),
  });
}