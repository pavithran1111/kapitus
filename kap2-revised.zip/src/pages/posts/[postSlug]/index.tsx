import { getNextStaticProps, is404 } from '@faustjs/next';
import { client, Post } from 'client';
import { Footer, Header, Advancedhero } from 'components';
import { GetStaticPropsContext } from 'next';
import Head from 'next/head';

interface MyPageProps {
  username: string;
  password: string;
}
export interface PostProps {
  post: Post | Post['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

export function PostComponent({ post, username, password }: PostProps) {
  const { useQuery } = client;
  const generalSettings = useQuery().generalSettings;

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={post?.seo?.metaDesc}
        opengraphTitle={post?.seo?.metaTitle}
        targetKeywords={post?.seo?.targetKeywords}
      />

      <Head>
        <title>
          {post?.title()} - {generalSettings.title}
        </title>
      </Head>

      <Advancedhero
        indexTitle=''
        title={post?.title()}
        bgImage={post?.featuredImage?.node?.sourceUrl()}
        alt={post?.heroAdvanced?.desktopBanner?.altText}
        column='one'
        slug={post?.slug}
      />

      <main className="content content-single">
        <div className="wrap">
          <div dangerouslySetInnerHTML={{ __html: post?.content() ?? '' }} />
        </div>
      </main>

      <Footer copyrightHolder={generalSettings.title} username={username} password={password} />
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  const { usePost } = client;
  const post = usePost();

  return <PostComponent post={post} username={username} password={password} />;
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

export function getStaticPaths() {
  return {
    paths: [],
    fallback: 'blocking',
  };
}
