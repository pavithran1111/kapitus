import { getNextStaticProps, is404 } from '@faustjs/next';
import { client, Post } from 'client';
import { Footer, Header, Advancedhero } from 'components';
import SearchBlogs from "../../../components/SearchBlogs";
import SubscribeBlog from "../../../components/forms/SubscribeBlog";
import PostLargeImage from "../../../components/PostLargeImage";
import Heading, { HeadingProps } from '../../../components/Heading';
import { GetStaticPropsContext } from 'next';
import styles from 'scss/components/Posts.module.scss';
import RecentPost from "../../../components/RecentPost";
import Category from "../../../components/Category";
import { useRouter } from 'next/router';
import useInView from "react-cool-inview";

interface MyPageProps {
  username: string;
  password: string;
}
export interface PostProps {
  post: Post | Post['preview']['node'] | null | undefined;
  username: string;
  password: string;
}

const POSTS_PER_PAGE = 9;
const RECENT_POST_COUNT = 5;

export function PostComponent({ post, username, password }: PostProps) {
  const { query = {} } = useRouter();
  const { postSlug, postCursor } = query;
  const { useQuery, usePosts, usePost, useCategory } = client;

  const generalSettings = useQuery().generalSettings;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });
  const category = useQuery()
  const categories = category.categories;
  const categ = categories({first: 50})

  const yoastData = useQuery();
  //const faceBook = yoastData?.seo?.social?.facebook;
  // const linkedIn = yoastData?.seo?.social?.linkedIn;
  
  const metaData = usePost();
  const isBefore = postSlug === 'before';

  const recentPosts = usePosts({
    after: !isBefore ? (postCursor as string) : undefined,
    before: isBefore ? (postCursor as string) : undefined,
    first: !isBefore ? RECENT_POST_COUNT : undefined,
    last: isBefore ? RECENT_POST_COUNT : undefined,
  });

  return (
    <>
      <Header
        title={generalSettings.title}
        description={generalSettings.description}
        metaDesc={post?.seo?.metaDesc}
        opengraphTitle={post?.seo?.metaTitle}
        targetKeywords={post?.seo?.targetKeywords}
      />
      <main className="content content-page">
      <div className="blogWrap">
      <div className="blogContainer">
        <section id={styles.post_list}>
         <div className={styles.single} id={`post-${post.id}`}>
          <div className={styles.prime}>
            <PostLargeImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />
          </div>
        </div>
        <main className="content content-single">
          <div className="wrap">
            <h3> {post?.title()}</h3>
            <div className={post?.title()} dangerouslySetInnerHTML={{ __html: post?.content() ?? '' }} />
          </div>
        </main>
        </section>
        </div>
        <div className="blogNav">
          <SearchBlogs />
          <RecentPost  />
          <SubscribeBlog username={username} password={password} />
          <Category categories={categ?.nodes} />
        </div>
      </div>
      </main>
      <section ref={observe}>
        {inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}
      </section>
    </>
  );
}

export default function Page({ username, password }: MyPageProps) {
  const { usePost } = client;
  const post = usePost();

  return <PostComponent post={post} username={username} password={password} />
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
    notFound: await is404(context, { client }),
  });
}

export async function getStaticPaths() {
  const values = await client.client.inlineResolved(() => {
    return client.client.query
      .posts({
        last: 50,
      })
      ?.nodes?.map((node) => node?.uri);
  });
  const paths = [];

  if (Array.isArray(values)) {
    paths.push(
      ...values
        .filter((value) => {
          return typeof value === 'string';
        }),
    );
  }
  return {
    paths: [],
    fallback: 'blocking',
  };
}
