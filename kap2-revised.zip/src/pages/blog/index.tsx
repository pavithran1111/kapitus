import { getNextStaticProps } from '@faustjs/next';
import { client, PageIdType } from 'client';
import { Footer, Header, Pagination } from 'components';
import RecentPost from "../../components/RecentPost";
import Category from "../../components/Category";
import SearchBlogs from "../../components/SearchBlogs";
import Blog from "../../components/Blog";
import SubscribeBlog from "../../components/forms/SubscribeBlog";
import { GetStaticPropsContext } from 'next';
import { useRouter } from 'next/router';
import React from 'react';
import styles from 'scss/pages/posts.module.scss';
import useInView from "react-cool-inview";
const POSTS_PER_PAGE = 9;
const ALL_POST = 1000;
const RECENT_POST_COUNT = 5;
 
export interface PageProps {
  username: string;
  password: string;
}
export default function Page({username, password }: PageProps) {
  const { query = {} } = useRouter();
  const { postSlug, postCursor } = query;
  const { usePage, usePosts, useQuery, useCategory } = client;

  const page = usePage({
    id: 'blog',
    idType: PageIdType.URI,
  });

  const generalSettings = useQuery().generalSettings;
  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  const isBefore = postSlug === 'before';
  
  const posts = usePosts({
    after: !isBefore ? (postCursor as string) : undefined,
    before: isBefore ? (postCursor as string) : undefined,
    first: !isBefore ? POSTS_PER_PAGE : undefined,
    last: isBefore ? POSTS_PER_PAGE : undefined,
  });

  const po = useQuery();

  const p = po?.posts;
  const allPost = p({first: 100})

  const category = useQuery()
  const categories = category.categories;
  const categ = categories({first: 50})

  const recentPosts = usePosts({
    after: !isBefore ? (postCursor as string) : undefined,
    before: isBefore ? (postCursor as string) : undefined,
    first: !isBefore ? RECENT_POST_COUNT : undefined,
    last: isBefore ? RECENT_POST_COUNT : undefined,
  });
  if (useQuery().$state.isLoading) {
    return null;
  }
  return (
    <>
      <Header
        title={`${generalSettings.title} - ${generalSettings.description}`}
        description={generalSettings.description}
        metaDesc={page?.seo?.metaDesc}
        opengraphTitle={page?.seo?.metaTitle}
        targetKeywords={page?.seo?.targetKeywords}
      />
      
      <main className="content content-page">
        <div className="blogWrap">
          <div className="blogContainer" ref={observe}>
            <Blog
              allPosts={allPost?.nodes}
              posts={posts.nodes}
           // heading="Blog Posters"
              headingLevel="h2"
              postMainTitleLevel="h1"
              postTitleLevel="h4"
              id={styles.post_list}
            />
            <Pagination pageInfo={posts.pageInfo} basePath="/blog" />
          </div>
          <div className="blogNav">
            <SearchBlogs />
            <RecentPost />
            <SubscribeBlog username={username} password={password} />
            <Category categories={categ?.nodes} />
          </div>
        </div>
      </main>
      <section ref={observe}>
        {inView && <Footer copyrightHolder={generalSettings.title} username={username} password={password} />}
      </section>
    </>
  );
}

export async function getStaticProps(context: GetStaticPropsContext) {
  return getNextStaticProps(context, {
    Page: Page,
    client,
    props: {
      username: process.env.API_USERNAME,
      password: process.env.API_PASSWORD
    },
  });
}