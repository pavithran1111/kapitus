/* eslint-disable @next/next/no-img-element */
import styles from 'scss/components/SuccessSlider.module.scss';
import Images from 'next/image';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import Slider from 'react-carousel-responsive';
import 'react-carousel-responsive/dist/styles.css';
import { Page_Carouselhero_CarouselGroup1 , Page_Carouselhero_CarouselGroup2 , Page_Carouselhero_CarouselGroup3 } from 'client';

interface CarouselProps {
  carouselData: ( Page_Carouselhero_CarouselGroup1 | Page_Carouselhero_CarouselGroup2 | Page_Carouselhero_CarouselGroup3)[]
}

export default function SuccessSlider({ carouselData }: CarouselProps) {
  
  return (
    <Slider autoplay={true}>
    {carouselData.map((item, index) => item?.carouselImage?.sourceUrl() && 
    <section key={index} id="banner-text" className={`${styles.bgImage} ${styles.sliderhero}`}>
      <Images src={item?.carouselImage?.sourceUrl()} layout="fill" objectFit="cover" alt={``} priority />
      <div className={styles.successwrap}>
        <div className="" 
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: item?.carouselEditor ?? '' }}
        />
    </div>
    </section>
    )}
    </Slider>
  );
}