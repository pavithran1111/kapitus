import React from 'react';
import Link from 'next/link';
import { client } from 'client';
import { useRouter } from 'next/router';
import Heading, { HeadingProps } from './Heading';

const RECENT_POST_COUNT = 5;

function RecentPost(): JSX.Element {
  const { query = {} } = useRouter();
  const {  postCursor, paginationTerm } = query;
  const { useQuery, usePosts, useCategory } = client;
  
  const isBefore = paginationTerm === 'before';

  const recentPostList = useQuery()?.posts;  
  // const postsLimit = recentPostList? .posts;
  const recentPosts = recentPostList({first: !isBefore ? RECENT_POST_COUNT : undefined})

  return (
    <section>
      <h2>LATEST FROM KAPITUS</h2>
      {recentPosts?.nodes?.map((post, key) => (
        <div key={key}>
{/*           <Link href={`/blog/${post.slug}`} as={`/blog/${post.slug}`} passHref>
            <a>{post.title()}</a>
            
          </Link> */}
          <Heading level={`h5`}> 
            <Link href={`/blog/${post.slug}`}>
              <a>{post.title()}</a>
            </Link>
          </Heading>
          <hr />
        </div>
      ))}
    </section>
  );
}
export default RecentPost;