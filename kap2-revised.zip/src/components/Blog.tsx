import React, {useState} from 'react';
import Link from 'next/link';
import type { Post } from 'client';
import styles from 'scss/components/Posts.module.scss';
import PostImage from "./PostImage";
import PostLargeImage from "./PostLargeImage";
import Heading, { HeadingProps } from './Heading';
import useInView from "react-cool-inview";
import Highlighter from "react-highlight-words";
import ReactHtmlParser from 'react-html-parser';

interface Props {
  posts: Post[] | undefined;
  allPosts: Post[] | undefined;
  intro?: string;
  id?: string;
  heading?: string;
  headingLevel?: HeadingProps['level'];
  postTitleLevel?: HeadingProps['level'];
  postMainTitleLevel?: HeadingProps['level']
  readMoreText?: string;
}

export default function Blog({
  posts,
  allPosts,
  intro,
  heading,
  id,
  headingLevel = 'h1',
  postTitleLevel = 'h2',
  postMainTitleLevel='h1',
  readMoreText = 'Read more',
}: Props): JSX.Element {

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  //const [dataSource, setDataSource] = useState(allPosts)
  const [searchTerm, setSearchTerm]= useState("");

  const fetchPost = allPosts?.filter((post)=> {
    if(searchTerm!== '' ) {
      if(post?.content()?.toLowerCase()?.includes(searchTerm?.toLowerCase()) || post?.title()?.toLowerCase()?.includes(searchTerm?.toLowerCase())) {
        // console.log(searchTerm);
        return post;
      } 
    }
  })
  
  const postFilter = fetchPost.map((post, key) => {

    return (
      <div
        className={styles.single}
        key={post.id ?? ''}
        id={`post-${post.id}`}>
        <div>
          <PostImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />

          <Heading level={postTitleLevel} className={styles.title}> 
            <Link href={`/blog/${post.slug}`}>
              <a>{post.title()}</a>
            </Link>
          </Heading>
          <div
            className={styles.excerpt}
            // style={part.toLowerCase() === highlight.toLowerCase() ? { fontWeight: 'bold' } : {} }
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: post.excerpt() ?? '' }}
          />
          <Link href={`/blog/${post.slug}`}>
            <a aria-label={`Read more about ${post.title || 'the post'}`}>
              {readMoreText}
            </a>
          </Link>
        </div>
      </div>
    )
  })

  return (
    // eslint-disable-next-line react/jsx-props-no-spreading
    <section className={styles['posts-block']} {...(id && { id })}>
      <div >
        {heading && (
          <Heading level={headingLevel} className={styles.heading}>
            {heading}
          </Heading>
        )}
        {intro && <p className={styles.intro}>{intro}</p>}       
        <div >
          {posts.map((post, key) => (
            <div key={key}>
              {key === 0 ? (
                
              <div className={styles.single} id={`post-${post.id}`}>
                <div className={styles.prime}>
                  <PostLargeImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />
                  <Heading level={postMainTitleLevel} className={styles.title}>
                    <Link href={`/blog/${post.slug}`}>
                      <a>{post.title()}</a>
                    </Link>
                  </Heading>
                  <div
                    className={styles.excerpt}
                    dangerouslySetInnerHTML={{ __html: post.excerpt() ?? '' }}
                  />
                  <Link href={`/blog/${post.slug}`}>
                    <a aria-label={`Read more about ${post.title || 'the post'}`}>
                      {readMoreText}
                    </a>
                  </Link>
                </div>
              </div>
              ) : ( <div></div> )}
            </div>
          ))}
        </div>
        <section ref={observe}>
        {inView && 
        <div className="posts">
          {searchTerm!=="" ? (
            <>{postFilter}</>
          ) : (
            posts?.map((post) => (
            <div
              className={styles.single}
              key={post.id ?? ''}
              id={`post-${post.id}`}>
              <div>
                <PostImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />
                <Heading level={postTitleLevel} className={styles.title}> 
                  <Link href={`/blog/${post.slug}`}>
                    <a>{post.title()}</a>
                  </Link>
                </Heading>
                <Highlighter
                    searchWords={[searchTerm]}
                    autoEscape={true}
                    caseSensitive={false}
                    textToHighlight={post.excerpt().replace(/(<([^>]+)>)/ig , "") ?? ''}
                  />
                {/* <div
                  className={styles.excerpt}
                  // eslint-disable-next-line react/no-danger
                  dangerouslySetInnerHTML={{ __html: post.excerpt() ?? '' }}
                /> */}
                <Link href={`/blog/${post.slug}`}>
                  <a aria-label={`Read more about ${post.title || 'the post'}`}>
                    {readMoreText}
                  </a>
                </Link>
              </div>
            </div>
            ))
          )
          }
          {posts && posts?.length < 1 && <p>No posts found.</p>}
        </div>}
        </section>
      </div>
    </section>
  );
}
// export default Blog;