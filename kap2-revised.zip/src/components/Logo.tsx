import React from 'react';
import styles from 'scss/components/Header.module.scss';
import Router from "next/router";
import Images from 'next/image'
import Link from 'next/link'

 
interface Props { 
  
  LogoImg?: string;
  Params?: string;
//  phone: string;
}

const navigateToHome = () => {
  Router.push("/");
}

function Logo({
  LogoImg,
  Params
}: Props): JSX.Element {
  return (
    <section>
      <Link  href={`/${Params}`} passHref>
        <a>
          <div className={styles.logoIcon}>
            {LogoImg && <Images src={LogoImg} priority layout="fill" objectFit="cover" />}
          </div>
        </a>
      </Link>
    </section>
  );
}

export default Logo;
