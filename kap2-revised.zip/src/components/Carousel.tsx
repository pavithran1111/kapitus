/* eslint-disable @next/next/no-img-element */
import styles from 'scss/components/Carousel.module.scss';
import Images from 'next/image';
import Slider from 'react-carousel-responsive';
import 'react-carousel-responsive/dist/styles.css';
import { Page_Carousel_CarouselGroup1, Page_Carousel_CarouselGroup2, Page_Carousel_CarouselGroup3, ProductsService_Carousel_CarouselGroup1, ProductsService_Carousel_CarouselGroup2, ProductsService_Carousel_CarouselGroup3 } from 'client';

interface CarouselProps {
  data: (ProductsService_Carousel_CarouselGroup1 | ProductsService_Carousel_CarouselGroup2 | ProductsService_Carousel_CarouselGroup3 | Page_Carousel_CarouselGroup1 | Page_Carousel_CarouselGroup2 | Page_Carousel_CarouselGroup3)[]
}

export default function Carousel({ data }: CarouselProps) {
  return (
     <Slider autoplay={true}>
      {data.map((item, index) => (item?.carouselImageDesktop?.sourceUrl()) && 
        <section key={index} className={styles.twoColumn}>
          <div className={styles.col}><Images src={item?.carouselImageDesktop?.sourceUrl()}
            width={1000}
            height={800}
            alt={item?.carouselImageDesktop?.altText}
            layout="intrinsic"
            blurDataURL={item?.carouselImageDesktop?.sourceUrl()}
            placeholder="blur" 
            />
          </div>
          <div className={`${styles.col} ${styles.content}`}>
            <span>
              <p className={styles.textContent}>{item?.testimonial}</p>
            </span>
          </div>
        </section>
      )}
    </Slider>
  );
}