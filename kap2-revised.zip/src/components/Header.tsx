import React, { useEffect, useState } from 'react';
import styles from 'scss/components/Header.module.scss';
import Link from 'next/link';
import Head from 'next/head';
import { Example } from './MobileMenu/Example';
import Logo from './Logo';
import { useRouter } from "next/router";
import UtmParams from "./UtmParams"
// import {Helmet} from "react-helmet";

interface Props {
  title?: string;
  description?: string;
  bgImage?: string;
  metaDesc?: string;
  opengraphTitle?: string;
  targetKeywords?: string;
  proschema?: string;
 }

function Header({
    title = 'Header Placeholder',
    description,
    bgImage,
    metaDesc,
    opengraphTitle,
    targetKeywords,
    proschema = ''
  }: Props): JSX.Element {

  let key = ``
  let schema = ``
	if(proschema && proschema !== '') {
    let schema = `{"@context":"https:\/\/schema.org","name":"FAQ",`;
      JSON.parse(proschema).map(item => {
      key = item._seopress_pro_rich_snippets_type;
      schema += `"@type":"${item._seopress_pro_rich_snippets_type}",`;
      schema += `"mainEntity":[`;
      if(item._seopress_pro_rich_snippets_faq)
        Object.values(item._seopress_pro_rich_snippets_faq).map(item1 => {
        schema += `{"@type":"Question","name":"${item1['question']}","answerCount":"1","acceptedAnswer":{"@type":"Answer","text":"${item1['answer']}"}},`
        })
      schema = schema.slice(0, -1); 
      schema += `]}`;
      })
    }

  let { asPath } = useRouter();
  const [transparent, setTransparent] = useState(false)

  useEffect(()=>{
    setTransparent(()=>{
      if(asPath == '/success-stories')
        return true
    })
  }, [asPath])

  
  let Params = UtmParams(asPath)
  // const { menuItems } = client.useQuery()
  // const links = menuItems({
  //   where: { location: MenuLocationEnum.PRIMARY },
  // }).nodes;
  const LogoImg = "/images/_Kapitus_Logo_white.webp";

  return (
    <>
      <Head>
        <title>{opengraphTitle}</title>
        <meta name="description" content={metaDesc}></meta>
        <meta name="keywords" content={targetKeywords}></meta>
        <meta name="theme-color" content="#73b564" />
        <meta charSet="utf-8" />
        {/* Insert Pro Schemas */}
        <script type="application/ld+json" key={key}>
            {schema}
        </script>
      </Head>
      <div className={`${styles.topHeader} flex items-center`}>
          <ul className={styles.topList}>
            <li className={styles.twitter}>
              <Link href="https://twitter.com/KapitusFinance"><a>
              </a>
              </Link>
            </li>
            <li className={styles.linkedin}>
              <Link href="https://www.linkedin.com/company/kapitus/"><a>
              </a>
              </Link>
            </li>
            <li className={styles.facebook}>
              <Link href="https://twitter.com/KapitusFinance"><a>
              </a>
              </Link>
            </li>
            <li className={styles.instagram}>
              <Link href="https://www.instagram.com/kapitus_financing/"><a>
              </a>
              </Link>
            </li>
            <li className={styles.youtube}>
              <Link href="https://www.youtube.com/channel/UCvZ5ahnMH9jCnN0lP4rRROA"><a>
              </a>
              </Link>
            </li>
          </ul>
          <div className="phone-info ml-auto text-sm text-white">
            <span><a className="header-login text-sm text-white" href="https://portal.kapitus.com/">Login </a>| Call now: <a href="tel:+18007807133" className='text-sm text-white'> (800) 780-7133</a></span></div>
      </div>
      <header className={`${transparent ? styles.transparent : styles.bghead }`}>
        <div className={styles.wrap}>
          <div className={styles['title-wrap']}> 
              <div className={styles['site-title']}>
                <div className={styles.logoContainer}>  
                  <div className={styles.desktopLogo}>
                    <Logo LogoImg={LogoImg} Params={Params} />
                  </div>
                </div>
              </div>
            </div>
            {/* DESKTOP MENU ITEMS */}
            <div className={`${styles.menu}`}>
              <ul>
                {/* {links?.map((link) => (
                  <li key={`${link.label}$-menu`}>
                    <Link href={link.url ?? ''}>
                      <a href={`${link.url}${params}`}>{link.label}</a>
                    </Link>
                  </li>
                ))} */}
                <li>
                  <Link href={`/problems-we-solve${Params}`} passHref>
                    <a>
                      Problems We Solve
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href={`/products-we-offer${Params}`} passHref>
                      <a>
                        Products We Offer
                      </a>
                  </Link>
                </li>
                <li>
                  <Link href={`/partner${Params}`} passHref>
                      <a>
                        Partner
                      </a>
                  </Link>
                </li>          
                <li>
                  <Link href={`/blog${Params}`} passHref>
                      <a>
                        Blog
                      </a>
                  </Link>
                </li>    
                <li>
                  <Link href={`/the-kapitus-difference${Params}`} passHref>
                      <a className="button">
                        Difference
                      </a>
                  </Link>
                </li>                                    
                <li>
                  <span id="headeroll apply-now">
                    <Link href={`/fast-application${Params}`} passHref>
                      <a className="button">
                        APPLY NOW
                      </a>
                    </Link>
                  </span>
                </li>
              </ul>
            </div>
          </div>
          {/* MOBILE MENU ITEMS */}
      </header>
      <Example /> 
    </>
  );
}

export default Header;