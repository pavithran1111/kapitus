/* eslint-disable @next/next/no-img-element */
import { PressRelease as PressReleaseType } from 'client';

interface PressReleaseProps {
  press: PressReleaseType;
}

export default function PressRelease({ press }: PressReleaseProps) {

  return (
    <>
      <h2>{press?.title()}</h2>
      <div
          className="wrap"
          dangerouslySetInnerHTML={{ __html: press?.content() }}
      />
      </>
  );
}