import React, { useEffect, useState } from 'react';
import styles from 'scss/components/Header.module.scss';
import Link from 'next/link';
import Head from 'next/head';
import { Example } from './MobileMenu/Example';
import CustomLogo from './CustomLogo';
import { useRouter } from "next/router";
import UtmParams from "./UtmParams"
import { Page_Uniqueheader } from 'client';

interface Props {
  title?: string;
  description?: string;
  bgImage?: string;
  metaDesc?: string;
  opengraphTitle?: string;
  targetKeywords?: string;
  proschema?: string;
  headerData?: Page_Uniqueheader;
  slug?: string;
 }

function Header({
    title = 'Header Placeholder',
    description,
    bgImage,
    metaDesc,
    opengraphTitle,
    targetKeywords,
    proschema,
    headerData,
    slug
  }: Props): JSX.Element {

  let { asPath } = useRouter();  
  let Params = UtmParams(asPath)
  // const { menuItems } = client.useQuery()
  // const links = menuItems({
  //   where: { location: MenuLocationEnum.PRIMARY },
  // }).nodes;
  const LogoImg = "/images/kap_logo.webp";
  
  return (
    <>
      <Head>
        <title>{opengraphTitle}</title>
        <meta name="description" content={metaDesc}></meta>
        <meta name="keywords" content={targetKeywords}></meta>
        <meta name="theme-color" content="#73b564" />
        <meta charSet="utf-8" />
      </Head>
      <header className={styles.customhead}>
        <div className={styles.wrap}>
          <div className={styles['title-wrap']}> 
              <div className={styles['site-title']}>
                <div className={styles.logoContainer}>  
                  <div className={styles.desktopLogo}>
                    <CustomLogo LogoImg={LogoImg} Params={Params} slug={slug} />
                  </div>
                </div>
              </div>
            </div>
            {/* DESKTOP MENU ITEMS */}
            <div className={`${styles.custommenu}`}>
              <ul>
                {slug == 'nav' && <li>
                  <Link href="tel:6466791810" passHref>
                  <a className="phone-number text-kapitus font-semibold" href="tel:6466791810">(646) 679-1810</a>
                  </Link>
                </li>}
                <li>
                  <span id="headeroll apply-now">
                    <Link href={`/fast-application${Params}`} passHref>
                      <a className="button">
                        APPLY NOW
                      </a>
                    </Link>
                  </span>
                </li>
              </ul>
            </div>
          </div>
          {/* MOBILE MENU ITEMS */}
      </header>
      <Example /> 
    </>
  );
}

export default Header;