/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect } from 'react';
import styles from 'scss/components/Advancedhero.module.scss';
import Images from "next/image"
import PopUpGetStarted from "./PopUpGetStarted";
import PopUpPartner from "./PopUpPartner";
import ContactForm from "./forms/ContactForm";
import CommonShortForm from './forms/CommonShortForm'
import EquipShortForm from './forms/EquipShortForm'
import InvoiceShortForm from './forms/InvoiceShortForm'
import { Svg500152476245421484GoogleReviews45, WebsiteTrustmarks2021BusinessesFunded, WebsiteTrustmarks2021CapitalProvided } from "./secondary-svg-icons/svgs"

interface Props {
  title: string;
  indexTitle: string;
  id?: string;
  bgImage?: string;
  alt?: string;
  disclaimer?: string;
  column?: string;
  slug?: string;
  type?: string;
  children?: React.ReactNode;
  buttonText?: string;
  buttonURL?: string;
  username?: string;
  password?: string;
}

function Advancedhero({
  title,
  indexTitle,
  id,
  bgImage,
  alt,
  disclaimer,
  column,
  slug,
  type,
  children,
  buttonText,
  buttonURL,
  username,
  password
}: Props): JSX.Element {
  
  const [popupgetstarted, setPopUpGetStarted] = useState(false)
  const [popuppartner, setPopUpPartner] = useState(false)
  const [mediacenter, setMediaCenter] = useState(false)

  const togglePop = (e) => {
    e.preventDefault();
    if(slug == 'partner'){
      setPopUpPartner((prevState) => !prevState)
    }
    else if(['problems-we-solve','home'].indexOf(slug) !== -1) {
      setPopUpGetStarted((prevState) => !prevState)
    }
    else if(slug == 'media-center') {
      setMediaCenter((prevState) => !prevState)
    }
  }

  useEffect(() => {

    //console.log(document.referrer.split('/')[2])
    let partner = document.getElementsByClassName("partners")
    if(Object.keys(partner).length > 0)
      partner[0].addEventListener('click', function(e) {
        e.preventDefault();
        var class1 = this.getAttribute("class");
        if(class1.includes('partners')){
          setPopUpPartner((prevState) => !prevState)
        }
      });
  })
  return (
    <section id="banner-text"
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...(id && { id })}
      className={`${styles.bgImage} ${styles.hero} ${column==`one` ? styles.extendPadding : styles.padding }`}>
        {bgImage && <Images src={bgImage} layout="fill" objectFit="cover" alt={alt} priority blurDataURL={bgImage} placeholder="blur" />}
        {column == 'one'? <div className={styles.wrap}>
          <div className="" 
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: title ?? '' }}
          />
        <h1>{indexTitle}</h1>
        <div className={styles.intro}>
          <div className={styles.children}>{children}</div>
          {buttonText && buttonURL && (
            <p>
              <a href={buttonURL} onClick={togglePop} className="button">
                {buttonText}
              </a>
            </p>
          )}
        </div>
      </div> : (<div className={styles.wrap}>
        <div className={styles.col}>
         <div
            className=""
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: title ?? '' }}
          />
          {type == 'reviews' && <div className='reviews'>
            <div className='isotopes'>
              <WebsiteTrustmarks2021BusinessesFunded className="isotopeItem isotopeItem1" width={185} height={50} />
              <Svg500152476245421484GoogleReviews45 className="isotopeItem isotopeItem2" width={176} height={45} />
              <WebsiteTrustmarks2021CapitalProvided className="isotopeItem isotopeItem3" width={130} height={43} />
            </div>
          </div>}
         <div
            className=""
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: disclaimer ?? '' }}
          />
        </div>
        <div className={styles.col}>      
        {( ['business-loans','helix-healthcare-financing', 'line-of-credit', 'purchase-order-financing', 'revenue-based-financing', 'sba-loans', 'products-we-offer', 'concierge-services'].indexOf(slug) !== -1) && (
          <CommonShortForm username={username} password={password} />
        )}
          {slug == 'equipment-financing' && <EquipShortForm username={username} password={password} />}
          {slug == 'invoice-factoring' && <InvoiceShortForm username={username} password={password} />}
        </div>
      </div>)}
      {popupgetstarted ? <PopUpGetStarted toggle={setPopUpGetStarted} username={username} password={password} /> : null}
      {popuppartner ? <PopUpPartner toggle={setPopUpPartner} username={username} password={password} /> : null}
      {mediacenter ? <ContactForm toggle={setMediaCenter} username={username} password={password} /> : null}
    </section>
  );
}

export default Advancedhero;
