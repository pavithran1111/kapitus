/* eslint-disable @next/next/no-img-element */
import { ProductsService as ProductsServiceType } from 'client';
import { Advancedhero, Intro, Faqs, Relatedblogs, CommonCard, Carousel } from 'components';
import Images from "next/image";
import styles from 'scss/components/ProductsServices.module.scss';
import LastCTA from "../LastCTA";
import useInView from "react-cool-inview";

interface ProductsServiceProps {
  productsService: ProductsServiceType;
  username: string;
  password: string;
}

export default function ProductsServices({ productsService, username, password }: ProductsServiceProps) {
  const faqlists = { faq1 : [productsService?.faqSection?.faqGroup1?.faqQuestion, productsService?.faqSection?.faqGroup1?.faqAnswer] , faq2: [productsService?.faqSection?.faqGroup2?.faqQuestion, productsService?.faqSection?.faqGroup2?.faqAnswer], faq3: [productsService?.faqSection?.faqGroup3?.faqQuestion, productsService?.faqSection?.faqGroup3?.faqAnswer], faq4: [productsService?.faqSection?.faqGroup4?.faqQuestion, productsService?.faqSection?.faqGroup4?.faqAnswer], faq5: [productsService?.faqSection?.faqGroup5?.faqQuestion, productsService?.faqSection?.faqGroup5?.faqAnswer], faq6: [productsService?.faqSection?.faqGroup6?.faqQuestion, productsService?.faqSection?.faqGroup6?.faqAnswer], faq7: [productsService?.faqSection?.faqGroup7?.faqQuestion, productsService?.faqSection?.faqGroup7?.faqAnswer] }

  const cardGroup = [productsService?.CardRows?.cardGroup1, productsService?.CardRows?.cardGroup2, productsService?.CardRows?.cardGroup3 ]
  const cardGroup1 = [productsService?.CardRows?.cardGroup4, productsService?.CardRows?.cardGroup5, productsService?.CardRows?.cardGroup6]
  const cardGroup2 = [productsService?.CardRows?.cardGroup7, productsService?.CardRows?.cardGroup8, productsService?.CardRows?.cardGroup9]

  const carousel = [productsService?.carousel?.carouselGroup1, productsService?.carousel?.carouselGroup2, productsService?.carousel?.carouselGroup3]

  const { observe, inView } = useInView({
    // Stop observe when the target enters the viewport, so the "inView" only triggered once
    unobserveOnEnter: true,
    // For better UX, we can grow the root margin so the image will be loaded before it comes to the viewport
    rootMargin: "50px",
  });

  return (
    <>
      <Advancedhero
        title={productsService?.heroAdvanced?.advancedBannerEditor}
        indexTitle=''
        bgImage={productsService?.heroAdvanced?.desktopBanner?.sourceUrl()}
        alt={productsService?.heroAdvanced?.desktopBanner?.altText}
        disclaimer={productsService?.heroAdvanced?.disclaimer}
        column='two'
        slug={productsService?.slug}
        type="reviews"
        username={username}
        password={password}
      />
      {(productsService?.CardRows?.cardGroup1?.cardTitle && inView) &&
        <CommonCard
          cardMainTitle={productsService?.CardRows?.cardMainTitle}
          cardData={cardGroup}
          cardData1={cardGroup1}
          cardData2={cardGroup2}
        />
      }

      {productsService?.intro?.introTitle &&
        <section ref={observe}>{inView && (<Intro 
          introTitle={productsService?.intro?.introTitle}
          subtitle={productsService?.intro?.introDescription}
      />)}</section>
      } 
      <section id="banner-text-color" ref={observe}>
      {inView && (<div
        className="wrap products_servicesh2"
        dangerouslySetInnerHTML={{ __html: productsService?.edit?.blockSectionBuilderEditor }}
      />)}
      </section>
      <section ref={observe}>
        {inView && (<Carousel data={carousel} />)}
      </section>

        {productsService?.faqSection?.faqTitle && 
        <section ref={observe}>
          {inView && (<Faqs faqlists={faqlists} />)}
        </section>
        }

      {productsService?.relatedBlogPosts?.relatedBlogEditor && 
      <section ref={observe}>
        {inView && (<Relatedblogs relatedblogs={productsService?.relatedBlogPosts} />)}
      </section>
      }
      {/*<div
        className={styles.wrap}
        dangerouslySetInnerHTML={{ __html: productsService?.content() }}
      /> */}
      <LastCTA
        title={productsService?.finalCta?.finalSectionTitle} 
        subtitle={''}
        description={productsService?.finalCta.finalSectionDescription}
        buttonText={productsService?.finalCta?.finalSectionButton?.title}
        buttonURL={productsService?.finalCta?.finalSectionButton?.url}
      />
    </>
  );
}