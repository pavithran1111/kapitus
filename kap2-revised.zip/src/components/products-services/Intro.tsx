import React from 'react';
 import styles from 'scss/components/Intro.module.scss';
 
interface Props { 
  introTitle: string;
  subtitle?: string;
  id?: string;
}
function Intro({
  introTitle,
  subtitle,
  id,
}: Props): JSX.Element {
  return (
    <section>
      <div className={styles.wrap}>
      <h2 className={styles.introTitle}>{introTitle}</h2>
      <p className={styles.subtitle}>{subtitle}</p>
      </div>
    </section>
  );
}
 
export default Intro;
