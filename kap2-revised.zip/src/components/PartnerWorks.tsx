import React, { useState } from 'react';
import styles from 'scss/components/PartnerWorks.module.scss';
import Images from 'next/image';

interface Props {
  cardMainTitle?: string;
}
 
function PartnerWorks({
  cardMainTitle,
}: Props): JSX.Element {
  const [expanded, setExpanded] = useState<false | number>(0);
  
  return (
      <div className={styles.wrap}>
      <h2>How it Works</h2>
      <div className={styles.CardNav}>
        {/* grid one */}
        <div className={styles.column}>
        <div className={styles.card}>
        <Images
          alt="partners"
          src={`/images/Register-as-A-Partner.svg`}
          layout="responsive"
          width={200}
          height={200}
        />  
        </div>
        <h4>Register as a partner</h4>
        </div>
        <div className={styles.column}>
        <div className={styles.card}>
        <Images
              alt="Mountains"
              src={`/images/Submit-Applications.svg`}
              layout="responsive"
              width={200}
              height={200}
        />  
        </div>
        <h4>Register as a partner</h4>
        </div>
        <div className={styles.column}>
        <div className={styles.card}>
        <Images
          alt="Mountains"
          src={`/images/Recieve-An-Offer.svg`}
          layout="responsive"
          width={200}
          height={200}
        /> 
        </div>
        <h4>Choose an Offer</h4>
        </div>
        <div className={styles.column}>
        <div className={styles.card}>
        <Images
              alt="Mountains"
              src={`/images/Recieve-A-Commission.svg`}
              layout="responsive"
              width={200}
              height={200}
        /> 
        </div>
        <h4>Get your commission </h4>
        </div>
      </div>
       </div>
  );
}

export default PartnerWorks;
