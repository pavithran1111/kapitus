import * as SecondarySvgIcons from "./secondary-svg-icons/svgs"
import styles from 'scss/components/SecondaryMenu.module.scss';
/* interface Props {
  name?: string;
} */

//function getSecondaryIcon({ name}: Props): JSX.Element {
function getSecondaryIcon(name, title='') {
  const mapIcon = {
    businessloans:SecondarySvgIcons.BusinessLoans,
    equipmentfinancing:SecondarySvgIcons.EquipmentFinancing,   
    helixhealthcarefinancing:SecondarySvgIcons.HelixHealthcareFinancing,  
    invoicefactoring:SecondarySvgIcons.InvoiceFactoring, 
    lineofcredit:SecondarySvgIcons.LineOfCredit, 
    purchaseorderfinancing:SecondarySvgIcons.PurchaseOrderFinancing,
    revenuebasedfinancing:SecondarySvgIcons.RevenueBasedFinancing,
    sbaloans:SecondarySvgIcons.SbaLoans,
  }

  if(name in mapIcon) {
    const IconComponent = mapIcon[name]
    title = title ? title.replaceAll('-','') : ``
    return <IconComponent className={name == title ? styles.imageBackground : `` } />
  }
  else {
    return null;
  } 
}

export default getSecondaryIcon;