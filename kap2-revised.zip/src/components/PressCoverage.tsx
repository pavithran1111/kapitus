/* eslint-disable @next/next/no-img-element */
import { PressCoverage as PressCoverageType } from 'client';
import Link from 'next/link';
import Images from 'next/image';

interface PressReleaseProps {
  presscoverage: PressCoverageType;
}

export default function PressCoverage({ presscoverage }: PressReleaseProps) {

  return (
      <div>
        <h2>{presscoverage?.title()}</h2>
        <Link href={presscoverage?.link || ""}>
          <a>
          {presscoverage?.featuredImage?.node?.sourceUrl() && <Images src={presscoverage?.featuredImage?.node?.sourceUrl()} 
            layout="responsive"
            width={500}
            height={300}
            alt={presscoverage?.title()}
          />}
          </a>
        </Link>
      </div>
  );
}