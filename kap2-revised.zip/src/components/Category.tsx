import React from 'react';
import styles from 'scss/components/RecentPost.module.scss';
import Link from 'next/link';
import Images from 'next/image';
import { client } from 'client';

// interface Props {
//   posts: Post[] | undefined;
// }

function Category({
    categories
}): JSX.Element {
  
  return (
    <section>
    <h2>CATEGORIES</h2>
        {categories?.map((category, key) => (
            <div key={key}>
            <Link href={`/category/${category?.slug}`} passHref><a><div>{category?.name}</div></a></Link>
          <hr />
            </div>
        ))}
    </section>
  );
}

export default Category;
