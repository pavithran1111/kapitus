import CTA from './CTA';
import Footer from './Footer';
import Header from './Header';
import Hero from './Hero';
import Posts from './Posts';
import Card from './Card'
import CommonCard from './CommonCard'
import Pagination from './Pagination';
import ProductsServices from './products-services/ProductsServices';
import TeamMembers from './TeamMembers';
import Advancedhero from './Advancedhero';
import Intro from './products-services/Intro';
import Faqs from './products-services/Faqs';
import PartnerData from './PartnerData';	
import Relatedblogs from './products-services/Relatedblogs';
import PressRelease from './PressRelease';
import PressCoverage from './PressCoverage'
import MediaCenter from './MediaCenter'
import PartnerWorks from './PartnerWorks'
import Carousel from './Carousel'
import SecondaryMenu from './SecondaryMenu';

export { CTA, Footer, Header, Hero, Posts, Card, CommonCard, Pagination, ProductsServices, TeamMembers, Advancedhero, Intro, Faqs, PartnerData, Relatedblogs, PressRelease, PressCoverage, MediaCenter, PartnerWorks, Carousel, SecondaryMenu };
