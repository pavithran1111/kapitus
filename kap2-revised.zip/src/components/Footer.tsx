import React from 'react';
import styles from 'scss/components/Footer.module.scss';
import NewsLetter from "../components/forms/NewsLetter";
import Link from 'next/link';
import { client, MenuLocationEnum } from 'client';
import { useRouter } from "next/router";
import UtmParams from "./UtmParams"

interface Props {
  title?: string;
  description?: string;
  copyrightHolder?: string;
  username?: string;
  password?: string;

}

function Footer({
  title = '',
  description,
  username = '',
  password = '',
}: Props): JSX.Element {
  const { menuItems } = client.useQuery()
  let { asPath } = useRouter();
  let params = UtmParams(asPath)

  const ColumnOne = [{label:"About Us", url:`/about-us/${params}`}, {label:"Media Center", url: `/media-center/${params}`}, {label:"Team", url:`/about-us/#teams${params?`/`+params:``}`}, {label:"Careers", url:"https://kapitus.breezy.hr/"}, {label: "Events", url: `/events${params}`}, {label: "Success Stories", url: `/success-stories/${params}`}, {label: "The Kapitus Difference", url: `/the-kapitus-difference/${params}`}, {label: "Developer Documentation", url: `/developer-documentation/${params}`}, {label: "Blog", url: `/blog/${params}`}]

  const ColumnTwo = [{label:"Products We Offer", url: `/products-we-offer/${params}`}, {label:"Revenue Based Financing", url: `/products-services/revenue-based-financing/${params}`}, {label:"Helix® Healthcare Financing", url:`/products-services/helix-healthcare-financing/${params}`}, {label: "Business Loans", url: `/products-services/business-loans/${params}`}, {label: "SBA Loans", url: `/products-services/sba-loans/${params}`}, {label: "Line of Credit", url: `/products-services/line-of-credit/${params}`}, {label: "Invoice Factoring", url: `/products-services/invoice-factoring/${params}`}, {label: "Equipment Financing", url: `/products-services/equipment-financing/${params}`}, {label: "Purchase Order Financing", url: `/products-services/purchase-order-financing/${params}`}, {label: "Concierge Services", url: `/products-services/concierge-services/${params}`}]

  const ColumnThree = [{label:'(800) 780-7133', url:"tel:18007807133"}, {label:'Contact Us', url: `/contact-us/${params}`}]

  // const ColumnOne = menuItems({
  //   where: { location: MenuLocationEnum.FOOTER },
  // }).nodes;
  
  // const ColumnTwo = menuItems({
  //   where: { location: MenuLocationEnum.HCMS_MENU_FOOTER },
  // }).nodes;
  
  // const ColumnThree = menuItems({
  //   where: { location: MenuLocationEnum.HCMS_MENU_HEADER },
  // }).nodes;
  
// function Footer({ copyrightHolder = 'Company Name' }: Props): JSX.Element {
//  const year = new Date().getFullYear();

  return (
 //   <footer className={styles.main}>
//      <div className={styles.wrap}>
//        <p>{`© ${year} ${copyrightHolder}. All rights reserved.`}</p>
//      </div>
//    </footer>
<footer className={styles.footer}>
<div className={styles.wrap}>
  <div className={styles['title-wrap']}>
    <p className={styles['site-title']}>
      <Link href="/">
        <a>{title}</a>
      </Link>
    </p>
 
    {description && <p className={styles.description}>{description}</p>}
  </div>

  <div className={styles.features}>
    <ul>
      {ColumnOne?.map((link) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={link.url}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    <ul>
      {ColumnTwo?.map((link) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={link.url}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    <ul>
      {ColumnThree?.map((link) => (
        <li key={`${link.label}$-menu`}>
          <Link href={link.url ?? ''}>
            <a href={link.url}>{link.label}</a>
          </Link>
        </li>
      ))}
    </ul>
    {/* <ul>
      <li> 
          <h5> Signup For Our Newsletter</h5>
          <input type="text" name="Email" />
      </li>
    </ul> */}
    <div className="xs:text-left md:text-center">
      <NewsLetter username={username} password={password} />
    </div>
    {/* 
      <li>
        <Link href="https://github.com/wpengine/faustjs">
          <a
            className="button"
            href="https://github.com/wpengine/faustjs">
            GitHub
          </a>
        </Link>
      </li>
    */} 
  </div>
</div>

    <div className={`${styles.topHeader} flex items-center`}>
      <div className={`${styles.copyright} text-xs text-white`}>
      Kapitus, LLC or its affiliates. All rights reserved. Kapitus, LLC, Kapitus.com, and the Kapitus logo are registered trademarks of Kapitus, Inc. or its affiliates. | Loans made in California are issued by Strategic Funding Source, Inc. dba Kapitus, pursuant to California Finance Lenders License No. 603-G807. </div>
    
      <ul className={`ml-auto ${styles.topList}`}>
            <li className={styles.twitter}>
              <Link href="https://twitter.com/KapitusFinance"><a>
              </a>
              </Link>
            </li>
            <li className={styles.linkedin}>
              <Link href="https://www.linkedin.com/company/kapitus/"><a>
              </a>
              </Link>
            </li>
            <li className={styles.facebook}>
              <Link href="https://twitter.com/KapitusFinance"><a>
              </a>
              </Link>
            </li>
            <li className={styles.instagram}>
              <Link href="https://www.instagram.com/kapitus_financing/"><a>
              </a>
              </Link>
            </li>
            <li className={styles.youtube}>
              <Link href="https://www.youtube.com/channel/UCvZ5ahnMH9jCnN0lP4rRROA"><a>
              </a>
              </Link>
            </li>
          </ul>
    </div>
{/* <div className={styles.wrap}>
  <p>{`© ${year} ${copyrightHolder}. All rights reserved.`}</p>
</div> */}
     
</footer>);
}
export default Footer;