import React from 'react';
import Link from 'next/link';
import type { Post } from 'client';
import styles from 'scss/components/Posts.module.scss';
import Heading, { HeadingProps } from './Heading';
import { Advancedhero } from 'components';
import PostImage from "./PostImage";

interface Props {
  posts: Post[] | undefined;
  intro?: string;
  id?: string;
  heading?: string;
  headingLevel?: HeadingProps['level'];
  postTitleLevel?: HeadingProps['level'];
  readMoreText?: string;
}
function Posts({
  posts,
  intro,
  heading,
  id,
  headingLevel = 'h1',
  postTitleLevel = 'h2',
  readMoreText = 'Read more',
}: Props): JSX.Element {
  return (
    // eslint-disable-next-line react/jsx-props-no-spreading
    <section className={styles['posts-block']} {...(id && { id })}>
      {posts.map((post, key) => (
        <div key={key}>
          {key === 0 ? (
          <div
            className={styles.single}
            id={`post-${post.id}`}>
            <div className={styles.prime}>
            <PostImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />
              {/* <Advancedhero
                  bgImage={post?.featuredImage?.node?.sourceUrl()} 
              /> */}
              <Heading level={postTitleLevel} className={styles.title}>
                <Link href={`/posts/${post.slug}`}>
                  <a>{post.title()}</a>
                </Link>
              </Heading>
              <div
                className={styles.excerpt}
                dangerouslySetInnerHTML={{ __html: post.excerpt() ?? '' }}
              />
              <Link href={`/posts/${post.slug}`}>
                <a aria-label={`Read more about ${post.title || 'the post'}`}>
                  {readMoreText}
                </a>
              </Link>
            </div>
          </div>
          ) : ( <div></div> )}
        </div>
      ))}
      <div className="wrap">
        {heading && (
          <Heading level={headingLevel} className={styles.heading}>
            {heading}
          </Heading>
        )}
        {intro && <p className={styles.intro}>{intro}</p>}
        <div className="posts">
          {posts.map((post, key) => (
            <div
              className={styles.single}
              key={post.id ?? ''}
              id={`post-${post.id}`}>
              <div>
              <PostImage imageSrcUrl={post?.featuredImage?.node?.sourceUrl()} />
                <Heading level={postTitleLevel} className={styles.title}>
                  <Link href={`/posts/${post.slug}`}>
                    <a>{post.title()}</a>
                  </Link>
                </Heading>
                <div
                  className={styles.excerpt}
                  // eslint-disable-next-line react/no-danger
                  dangerouslySetInnerHTML={{ __html: post.excerpt() ?? '' }}
                />
                <Link href={`/posts/${post.slug}`}>
                  <a aria-label={`Read more about ${post.title || 'the post'}`}>
                    {readMoreText}
                  </a>
                </Link>
              </div>
            </div>
          ))}
          {posts && posts?.length < 1 && <p>No posts found.</p>}
        </div>
      </div>
    </section>
  );
}

export default Posts;
