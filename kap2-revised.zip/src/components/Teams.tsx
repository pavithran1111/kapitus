import Masonry, { ResponsiveMasonry } from "react-responsive-masonry"
import React, { useState } from "react";
import styles from 'scss/components/Teams.module.scss';
import Images from 'next/image';
import Slider from 'react-carousel-responsive';
import Modal from "./Modal";
import Link from 'next/link';

function Teams({}): JSX.Element {

  const team = ['0-AndyReiser.webp', '1-BenJohnston.webp', '2-AnthonyRose.webp', '3-ArunNarayan.webp', '4-JeffNewman.webp', '5-JoshJones.webp', '6-MichaelJesseCarlson.webp', '7-EllaHaman.jpg']

  const data =  [{image:'0-AndyReiser.webp',name:'Andrew Reiser Chairman', title:'Chief Executive Officer', desc:'Prior to founding Kapitus in 2006, Andy served as the CEO of Arcavista Corporation, a Managing Director of Donald & Co. Securities, Inc., EVP of Fidelco Capital Group, and President of Windsor Group, Inc. He began his careers as a CPA with Coopers & Lybrand and Price Waterhouse. He holds a BS from Boston University"s Questrom School of Business.'}, {image:'1-BenJohnston.webp',name:'Ben Johnston', title:'Chief Operating Office', desc:'Ben joined Kapitus in 2014 as Chief Strategy Officer and became COO in January 2017. Prior to joining Kapitus, Ben was a Principal of Pine Brook Partners, a New York-based private equity firm, a Senior Associate at Lightyear Capital and an Analyst in the Office of the Chairman at PaineWebber. He holds a BA from Colby College and an MBA from the University of Michigan’s Ross School of Business.'},{image:'2-AnthonyRose.webp',name:'Anthony Rose', title:'Chief Financial Officer', desc:'Anthony joined Kapitus in February of 2018 as CFO. Prior to joining Kapitus, Anthony was Chief Administrative Officer of Dime Community Bancshares, CFO of ISI Group, CFO of the Global Equities Investment Bank at Credit Suisse, VP of Capital and Balance Sheet Strategy and FP&A at JPMorgan Chase, as well as an Equity Research Analyst at JPMorgan Chase. He holds a BA from the University of Wisconsin and an MBA from Columbia University.'},{image:'3-ArunNarayan.webp',name:'Arun Narayan', title:'Chief Product Officer', desc:'Arun joined Kapitus in 2015 as Senior Vice President of Risk & Analytics after previously serving as Vice President and Managing Director of Lighting Science Group Corporation, Management Consultant for PRTM, Manager of Discover Financial services and Marketing Manager at Infosys Technologies Ltd. Arun holds an MBA from the University of Michigan Ross School of Business.'},{image:'4-JeffNewman.webp',name:'Jeff Newman', title:'Chief Risk Officer', desc:'Jeffrey joined Kapitus in March 2018 as Chief Risk Officer. Jeffrey has over 25 years of Risk Management experience at Citibank and GE Capital (now known as Synchrony Financial). Prior to joining Kapitus, he was Chief Credit Officer at Citibank’s US Retail Bank for Consumer and Small Business lending. Jeffrey has an MBA from Carnegie Mellon’s Tepper Business School and a BA from Franklin & Marshall College.'},{image:'5-JoshJones.webp',name:'Josh Jones', title:'Chief Revenue Officer', desc:'Josh Jones joined Kapitus in 2015 when the lending facility he owned and operated was acquired. Josh has a proven track record of successfully establishing, reorganizing, and scaling businesses within FinTech. With over 15 years of experience, he has a specialization in building brands as well as distributing near prime credit products. Josh continues to run sales and marketing for Kapitus, keep up with his workout regiment, surfs or snowboards on the weekend, enjoys a sushi dinner, and loves to spend time with his family.'},{image:'6-MichaelJesseCarlson.webp',name:'Jesse Carlson', title:'General Counsel', desc:'Jesse is the Senior Vice President and General Counsel of Kapitus. Prior to joining Kapitus in June of 2017, he served as Counsel in the Professional Liability & Financial Crimes Section of the FDIC’s Legal Division and practiced at Williams & Connolly LLP, where he focused on complex financial services, litigation and professional liability litigation. He also served as the Judicial Law Clerk to the Honorable John M. Rogers of the U.S. Court of Appeals for the Sixth Circuit. He received his law degree from the Georgetown University Law Center and his undergraduate degree from Colby College.'},{image:'7-EllaHaman.jpg',name:'Ella Haman', title:'Chief Technology Officer', desc:'Ella formally joined Kapitus in October of 2021 as Chief Technology Officer after working with the Kapitus technology team in a senior consultant capacity. As CTO, Ella will spearhead the build-out of next generation technology platforms at Kapitus. Prior to joining Kapitus, Ella was a Lead Consultant at Crosslake Technologies where she oversaw complex, large-scale technology initiatives across a myriad of industries, including Health Care, Financial Services, Retail, and Utilities. She has also held Chief Technology Officer roles at Jama Software, Bynder and BlackLine. Ella has a bachelor’s degree from the University of Minnesota.'}]

  const [clickedImg, setClickedImg] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(null);

  const handleClick = (item, index) => {
    setCurrentIndex(index);
    setClickedImg(item.image);
  };
  
  const handelRotationRight = () => {
    const totalLength = data.length;
    if (currentIndex + 1 >= totalLength) {
      setCurrentIndex(0);
      const newUrl = data[0].image;
      setClickedImg(newUrl);
      return;
    }
    const newIndex = currentIndex + 1;
    const newUrl = data.filter((item) => {
      return data.indexOf(item) === newIndex;
    });
    const newItem = newUrl[0].image;
    setClickedImg(newItem);
    setCurrentIndex(newIndex);
  };

  const handelRotationLeft = () => {
    const totalLength = data.length;
    if (currentIndex === 0) {
      setCurrentIndex(totalLength - 1);
      const newUrl = data[totalLength - 1].image;
      setClickedImg(newUrl);
      return;
    }
    const newIndex = currentIndex - 1;
    const newUrl = data.filter((item) => {
      return data.indexOf(item) === newIndex;
    });
    const newItem = newUrl[0].image;
    setClickedImg(newItem);
    setCurrentIndex(newIndex);
  };
  
  return (
    <section
      // eslint-disable-next-line react/jsx-props-no-spreading
      className={styles.hero}>
    <h2 id="teams" className={styles.title}>Meet The Team Leadership</h2>
    <div className={`wrapper ${styles.wrap}`}>
    <ResponsiveMasonry columnsCountBreakPoints={{350: 2, 750: 3, 900: 4}}>
      <Masonry>
        {data.map((item, index) => 
          (<div key={`${index}team`} className={styles.containerImage}>
            <Images
              className={styles.imgPad}
              key={index}
              src={`/images/teams/${item?.image}`}
              width={325}
              height={400}
              alt={``}
              onClick={() => handleClick(item, index)}
          /></div>)
        )}
      </Masonry>
    </ResponsiveMasonry>
    {clickedImg && (
      <Modal
        clickedImg={clickedImg}
        handelRotationRight={handelRotationRight}
        data={data[currentIndex]}
        setClickedImg={setClickedImg}
        handelRotationLeft={handelRotationLeft}
      />
    )}
  </div>

  <div className={styles.MobileSlider}>
    <div className={styles.margin} />
    <Slider autoplay={false}>
      {data.map((item, index) => 
        <section key={index} className={styles.teamMobileWrap}>
          <div className={styles.teamMobileContent}>
          <Images className={styles.images} src={`/images/teams/${item?.image}`} width={250} height={300} />
          <div className={styles.milestoneContent}>
          <div className={styles.teamHeading}>
            <p>{item?.name}</p>
            <p>{item?.title}</p>
          </div>
          <div>{item?.desc}</div>
          </div>
          </div>
        </section>
      )}
    </Slider>
    </div>
    </section>
  );
}

export default Teams;
