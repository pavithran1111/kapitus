import React, { useEffect } from 'react'
var mapboxgl = require("mapbox-gl/dist/mapbox-gl.js");

interface Props {
  title?: string;
}

function MapBox({
  title
}: Props): JSX.Element {

  useEffect(() => {
    const map = new mapboxgl.Map({
      container: "kapitus-map",
      type: 'fill',
      style: "mapbox://styles/kapitus/cjtyljmho3vok1fntmnu0c8hq",
      center: [-1.98387980000001, 30.75704],
      zoom: 2,
    });
  });

  mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

  return (
      <div id="kapitus-map" className="w-full" /*style={{ height: 500, width: 1400 }}*/ style={{
        position: 'absolute',
        top: 0,
        bottom: 0,
        width: '100%',
        height: '100%',
        }}></div>
  );
}

export default MapBox;