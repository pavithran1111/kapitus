import React, { useEffect, useRef } from 'react';
import Timeline from '@mui/lab/Timeline';
import TimelineItem from '@mui/lab/TimelineItem';
import TimelineSeparator from '@mui/lab/TimelineSeparator';
import TimelineConnector from '@mui/lab/TimelineConnector';
import TimelineContent from '@mui/lab/TimelineContent';
import TimelineOppositeContent from '@mui/lab/TimelineOppositeContent';
import TimelineDot from '@mui/lab/TimelineDot';
import Slider from 'react-carousel-responsive';
import 'react-carousel-responsive/dist/styles.css';
import Typography from '@mui/material/Typography';
import styles from "scss/components/TimeLine.module.scss"
import { YourReferralGetsFunded, WorkingForAnIndustryLeader, ProcessingPartner, ConvenientPaymentOptions, RecieveAnOffer, SmallBusinessAssociationLoansRed, TaxBenefits } from "./secondary-svg-icons/svgs"

interface Props {
  title?: string;
}

function TimeLine({
  title
}: Props): JSX.Element {

  const fixed = useRef();

  const data =  [{year:2006,title:'Company Founded as Strategic Funding Source.', employee:'10', dollars:'$1.1M', business:'25'}, {year:2008,title:'Built out our customer service department and expanded with offices in Williamsburg, Virginia.', employee:'27', dollars:'$16.7M', business:'434'}, {year:2012,title:'Received first senior bank line from Capital One, expanding our ability to provide financing to business owners.', employee:'54', dollars:'$118.5M', business:'2,274'}, {year:2014,title:'Received $110 Million Line of Equity from Pine Brook Investment Firm enabling technology enhancements and the ability to deliver more capital to small businesses.', employee:'114', dollars:'$556.5M', business:'9,869'},{year:2016,title:'Added financing marketplace to assist all businesses in acquiring financing regardless of their unique situation.', employee:'20', dollars:'$1.2B', business:'16,858'}, {year:2018,title:'Secured first securitization expandable to $500MM.', employee:'225', dollars:'$2B', business:'25,000'}, {year:2021,title:'', employee:'241', dollars:'$3B', business:'64,000'}]

  useEffect(() => {
    const handleScrollPos = () => {
      if (window.scrollY <= 795) {
        //fixed.current ? (fixed.current.style.position = "relative") : "";
        //fixed.current ? (fixed.current.style.top = "55px") : "";
        let element = document.getElementById("fixedtimeline").classList;
        element.add("timelinerelative");
        element.remove("timelinefixed");
        element.remove("timelineabsolute");
      } else if (window.scrollY > 795 && window.scrollY < 1550) {
        let element = document.getElementById("fixedtimeline").classList;
        element.add("timelinefixed");
        element.remove("timelinerelative");
        element.remove("timelineabsolute");
        //fixed.current ? (fixed.current.style.position = "fixed") : "";
        //fixed.current ? (fixed.current.style.top = "165px") : "";
      } else {
        //fixed.current ? (fixed.current.style.position = "absolute") : "";
        //fixed.current ? (fixed.current.style.top = "1489px") : "";
        let element = document.getElementById("fixedtimeline").classList;
        element.add("timelineabsolute");
        element.remove("timelinefixed");
        element.remove("timelinerelative");
      }

      var current;
      let section = [
        "section_0",
        "section_1",
        "section_2",
        "section_3",
        "section_4",
        "section_5",
        "section_6",
        //"section_7",
      ];
      section.map((item) => {

        if (document.getElementById(item).offsetTop < window.scrollY) {
          current = item;
        }
      });

      let fixedsection = [
        "section-0",
        "section-1",
        "section-2",
        "section-3",
        "section-4",
        "section-5",
        "section-6",
        "section-7",
      ];
      if (current) {
        let actele = current.replace("_", "-");

        fixedsection.map((item, i) => {
          if (item == actele) {
            let element = document.getElementById(item).classList;
            element.add("timelineactive");
            element.remove("timelineinactive");
          } else {
            let element = document.getElementById(item).classList;
            element.remove("timelineactive");
            element.add("timelineinactive");
          }
        });
      }
    };

    window.addEventListener("scroll", handleScrollPos);
    return () => window.removeEventListener("scroll", handleScrollPos);
  }, [])
  

  return (
    <>
    <h1 className={styles.mobileFont}>Our History</h1>
    <div className={styles.timelineWrap}>
      <div ref={fixed} className={styles.onefourth}>
      <div id="fixedtimeline" className={styles.metricesWrapper}>
        <div id="section-0" className="timelineactive">
          <div className={styles.employeeMetrices}>10<br />
          TOTAL EMPLOYEES</div>
          <div className={styles.secondMertrices}>$1.1M<br />
          DOLLARS FUNDED</div>
          <div className={styles.employeeMetrices}>25<br />
          BUSINESSES FUNDED</div>
        </div>
        <div id="section-1" className="timelineinactive">
          <div className={styles.employeeMetrices}>27<br />
          TOTAL EMPLOYEES</div>
          <div className={styles.secondMertrices}>$16.7M<br />
          DOLLARS FUNDED</div>
          <div className={styles.employeeMetrices}>434<br />
          BUSINESSES FUNDED</div>
        </div>
        <div id="section-2" className="timelineinactive">
        <div className={styles.employeeMetrices}>54<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$118.5M<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>2,274<br />
        BUSINESSES FUNDED</div>
        </div>
        <div id="section-3" className="timelineinactive">
        <div className={styles.employeeMetrices}>66<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$260.1M<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>4,767<br />
        BUSINESSES FUNDED</div>
        </div>
        <div id="section-4" className="timelineinactive">
        <div className={styles.employeeMetrices}>114<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$556.9M<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>9,869<br />
        BUSINESSES FUNDED</div>
        </div>
        <div id="section-5" className="timelineinactive">
        <div className={styles.employeeMetrices}>220<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$1.2B<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>16,858<br />
        BUSINESSES FUNDED</div>
        </div>
        <div id="section-6" className="timelineinactive">
        <div className={styles.employeeMetrices}>225<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$2B<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>25,000<br />
        BUSINESSES FUNDED</div>
        </div>
        <div id="section-7" className="timelineinactive">
        <div className={styles.employeeMetrices}>241<br />
        TOTAL EMPLOYEES</div>
        <div className={styles.secondMertrices}>$3B<br />
        DOLLARS FUNDED</div>
        <div className={styles.employeeMetrices}>64,000<br />
        BUSINESSES FUNDED</div>
        </div>
        </div>
      </div>
      <div className={styles.threefourth}>
      <Timeline position="alternate">
      <TimelineItem id="section_0">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
        2006
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot className={styles.removeBackground}>
            <YourReferralGetsFunded width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Company Founded as Strategic Funding Source.
          Company Founded as Strategic Funding Source.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_1">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2008
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
          <WorkingForAnIndustryLeader width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Built out our customer service department and expanded with offices in Williamsburg, Virginia.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_2">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2010
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
          <ProcessingPartner width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
            Through a refined underwriting process and a focus on the long-term, the company successfully remained profitable despite the economic recession.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_3">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2012
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
          <WorkingForAnIndustryLeader width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Built out our customer service department and expanded with offices in Williamsburg, Virginia.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_4">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2014
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
          <ConvenientPaymentOptions width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Received $110 Million Line of Equity from Pine Brook Investment Firm enabling technology enhancements and the ability to deliver more capital to small businesses.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_5">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2016
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
            <RecieveAnOffer width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Added financing marketplace to assist all businesses in acquiring financing regardless of their unique situation.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_6">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2018
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
          <TaxBenefits width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          Secured first securitization expandable to $500MM.
          </Typography>
        </TimelineContent>
      </TimelineItem>
      <TimelineItem id="section_7">
        <TimelineOppositeContent
          sx={{ m: 'auto 0' }}
          align="right"
          variant="h6"
          color="text.secondary"
        >
          2021
        </TimelineOppositeContent>
        <TimelineSeparator className={styles.seperator}>
          <TimelineConnector />
          <TimelineDot color="primary" className={styles.removeBackground}>
            <RecieveAnOffer width={90} height={90} />
          </TimelineDot>
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent sx={{ m: 'auto 0' }}>
          <Typography variant="h6" component="span">
          </Typography>
        </TimelineContent>
      </TimelineItem>
    </Timeline>
    </div>
    </div>

    <div className={styles.MobileSlider}>
    <Slider autoplay={false}>
      {data.map((item, index) => 
        <section key={index} className={styles.timelineMobileWrap}>
          <div className={styles.timelineMobileContent}>
          <YourReferralGetsFunded width={50} height={50} />
          <h2>{item?.year}</h2>
          <p>{item?.title}</p>
          <div className="matrices_mobile">
            <div className="wrap">
            <div className="qty">{item?.employee}</div>
            <div className={styles.mobileText}>TOTAL EMPLOYEES</div>
            </div>
            <div className="wrap wrap-second">
            <div className="qty">{item?.dollars}</div>
            <div className={styles.mobileText}>DOLLARS FUNDED</div>
            </div>
            <div className="wrap">
            <div className="qty">{item?.business}</div>
            <div className={styles.mobileText}>BUSINESSES FUNDED</div>
            </div>
            </div>
            </div>
        </section>
      )}
    </Slider>
    </div>
    </>);
}

export default TimeLine;