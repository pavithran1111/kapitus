/* eslint-disable @next/next/no-img-element */
import { TeamMember as TeamMembersType } from 'client';
import Images from 'next/image'
interface TeamMembersProps {
  teamMembers: TeamMembersType;
}

export default function TeamMembers({ teamMembers }: TeamMembersProps) {

  return (
    <div>
      {teamMembers?.featuredImage?.node?.sourceUrl() && <Images
        src={teamMembers?.featuredImage?.node?.sourceUrl()}
        alt={teamMembers?.singleTeamMember?.name}
        width={500} height={400} 
      />}
      <h2>{teamMembers?.title()}</h2>
      <p>{teamMembers?.content()}</p>
      <div
        className="bio"
        dangerouslySetInnerHTML={{ __html: teamMembers?.singleTeamMember?.bio }}
      />
    </div>
  );
}